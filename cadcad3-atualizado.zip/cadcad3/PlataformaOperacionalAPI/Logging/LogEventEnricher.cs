﻿using Serilog.Core;
using Serilog.Events;

namespace PlataformaOperacionalAPI.Logging;

public sealed class LogEventEnricher : ILogEventEnricher
{
    public void Enrich(LogEvent logEvent, ILogEventPropertyFactory propertyFactory)
    {
        if (!logEvent.Properties.TryGetValue("SourceContext", out var sourceContextValue))
            return;

        var sourceContext = sourceContextValue.ToString().Trim('"');

        var typeName = sourceContext.Split('.').Last();

        if (!typeName.EndsWith("Service", StringComparison.Ordinal))
        {
            logEvent.AddOrUpdateProperty(
                propertyFactory.CreateProperty("IsApplicationService", false));

            return;
        }

        var serviceName = typeName[..^"Service".Length];

        logEvent.AddOrUpdateProperty(
            propertyFactory.CreateProperty("ServiceName", serviceName));

        logEvent.AddOrUpdateProperty(
            propertyFactory.CreateProperty("IsApplicationService", true));
    }
}

