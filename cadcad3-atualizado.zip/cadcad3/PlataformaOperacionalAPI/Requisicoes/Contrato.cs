﻿using System.ComponentModel.DataAnnotations;

namespace PlataformaOperacionalAPI.Requisicoes
{
	public class Contrato
	{
		[Required]
		[StringLength(7, MinimumLength = 1)]
		[RegularExpression(@"^\d{1,7}$", ErrorMessage = "O contrato deve conter apenas números com até 7 dígitos.")]
		public string NuContrato { get; set; }

		[Required]
		[StringLength(2, MinimumLength = 1)]
		[RegularExpression(@"^\d{1,2}$", ErrorMessage = "O digito do contrato deve conter apenas números com até 2 dígitos.")]
		public string NuContratoDv { get; set; }
    }
}
