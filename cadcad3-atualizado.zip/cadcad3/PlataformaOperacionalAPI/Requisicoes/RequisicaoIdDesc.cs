﻿namespace PlataformaOperacionalAPI.Requisicoes
{
    public class RequisicaoIdDesc
    {
        public string CoOperacao { get; set; }
        public string Desc { get; set; }
    }
}
