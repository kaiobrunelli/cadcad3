﻿using System.ComponentModel.DataAnnotations;

namespace PlataformaOperacionalAPI.Requisicoes
{
	public class UnidadeDeMovimento
	{
		[Required]
		[StringLength(4, MinimumLength = 1)]
		[RegularExpression(@"^\d{1,4}$", ErrorMessage = "A unidade deve conter apenas números com até 4 dígitos.")]
		public string UnidadeMovimento { get; set; }

		[Required]
		[StringLength(1, MinimumLength = 1)]
		[RegularExpression(@"^\d{1,1}$", ErrorMessage = "O digito da unidade deve conter apenas números com até 1 dígitos.")]
		public string UnidadeMovimentoDv { get; set; }
	}
}
