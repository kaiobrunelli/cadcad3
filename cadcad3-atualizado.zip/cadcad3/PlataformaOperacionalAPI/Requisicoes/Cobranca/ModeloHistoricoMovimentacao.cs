﻿namespace PlataformaOperacionalAPI.Requisicoes.Cobranca
{
	public class ModeloHistoricoMovimentacao
	{
        public int IdModelo { get; set; }
        public string Historico { get; set; }
    }
}
