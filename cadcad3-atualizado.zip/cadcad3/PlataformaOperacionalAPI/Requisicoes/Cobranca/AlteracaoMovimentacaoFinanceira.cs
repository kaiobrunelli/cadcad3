﻿using RedeCaixaUtilitario.Domain.Model.Siapf;

namespace PlataformaOperacionalAPI.Requisicoes.Cobranca
{
	public class AlteracaoMovimentacaoFinanceira
	{
        public int CoMovimentacaoFinanceira { get; set; }
        public string AcaoUsuario { get; set; }
        public ConjuntoTo? TiposDeOperacao { get; set; }
    }
}
