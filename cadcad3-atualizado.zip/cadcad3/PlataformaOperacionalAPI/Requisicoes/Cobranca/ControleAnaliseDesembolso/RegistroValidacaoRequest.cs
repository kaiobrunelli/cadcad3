﻿//using ControleAnaliseDesembolso.Domain.Enums;

//namespace PlataformaOperacionalAPI.Requisicoes.Cobranca.ControleAnaliseDesembolso
//{
//    public class RegistroValidacaoRequest
//    {

//         public String? DeRegistro { get; set; }
//         public TipoRegistro TipoRegistro { get; set; }
      
//    }
//}
