﻿//using ControleAnaliseDesembolso.Application.Dtos.Request;

//namespace PlataformaOperacionalAPI.Requisicoes.Cobranca.ControleAnaliseDesembolso
//{
//    public class ValidacoesDesembolsoRequest
//    {
//        public int CoValidacao { get; set; }

//        public int CoDesembolso { get; set; }

//        public string? DeValidacao { get; set; }

//        public string? CampoVinculado { get; set; }

//        public bool Situacao { get; set; }

//        public List<RegistroValidacaoRequest> RegistroValidacoes { get; set; } = new();
//    }
//}
