﻿//using ControleAnaliseDesembolso.Application.Dtos.Request;
//    public class PedidoDesembolsoRequest
//    {
//        public string MatriculaSolicitante { get; set; } = string.Empty;

//        public int CoGigov { get; set; }
//        public string MatriculaGestor { get; set; } = string.Empty;
//        public int NuFpd { get; set; }
//        public string CoContratoAf { get; set; } = string.Empty;
//        public string CoContratoAfDv { get; set; } = string.Empty;
//        public string AgenteFinanceiro { get; set; } = string.Empty;
//        public string CnpjAf { get; set; } = string.Empty;
//        public string MutuarioFinal { get; set; } = string.Empty;
//        public string CnpjMutuarioFinal { get; set; } = string.Empty;

//        public string? AgenteTecnicoOperador { get; set; }
//        public string? CnpjAgenteTecnicoOperador { get; set; }
//        public string AgentePromotor { get; set; } = string.Empty;
//        public string CnpjAgentePromotor { get; set; } = string.Empty;
//        public int Programa { get; set; }
//        public bool UltimoDesembolso { get; set; }
//        public bool? Funcionalidade { get; set; }
//        public DateOnly? Concluido { get; set; } // se seria melhor colocar a data de quando a obra foi concluida ou um simples sim ou nao já resolve 
//        public DateOnly DtEngenharia { get; set; }
//        public int SituacaoObra { get; set; } // Normal, Atrasada

//        public DateOnly? DtSocioAmbiental { get; set; }
//        public decimal PercentualObra { get; set; }
//        public int TipoDesembolso { get; set; }  // Normal, Adiantamento  // Quais regras o tipo de desembolso interfere
//        public bool RetornoParcial { get; set; } // se o contrato já finalizou o periodo de carencia, existe uma data no APF, podemos colocar ela como parametro para trazer
//        public bool PlacaLocal { get; set; }
//        public bool LicensaInstalacao { get; set; } // só é verificado no primeiro desembolso (Caso venha negativo)
//        public bool LicensaOperacao { get; set; } // só é verificado no ultimo desembolso (Caso venha NSA ou negativo)
//        public decimal SolicitadoVi { get; set; }
//        public decimal GlossadoVi { get; set; }
//        public decimal AceitoVi { get; set; }

//        public decimal ParticipacaoFgts { get; set; }
//        public decimal Contrapartida { get; set; }
//        public decimal ValorEmprestimo { get; set; }
//        public decimal Desembolsado { get; set; }
//        public decimal SaldoADesembolsar { get; set; }
//        public bool Excepcionalizado { get; set; }
//        public decimal ContrapartidaAtual { get; set; }
//        public decimal Integralizado { get; set; }
//        public decimal SaldoAIntegralizar { get; set; }
//        public bool ContrapartidaAlterada { get; set; }

//        public List<ValidacaoDesembolsoRequest> ValidacoesDesembolsoRequest { get; set; } = new();
//    }