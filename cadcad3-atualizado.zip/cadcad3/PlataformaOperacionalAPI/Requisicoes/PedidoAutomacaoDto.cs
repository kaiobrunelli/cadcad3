﻿namespace PlataformaOperacionalAPI.Requisicoes
{
	public class PedidoAutomacaoDto
	{
        public string Senha { get; set; }
        public bool MyExtra { get; set; } = false;
    }
}
