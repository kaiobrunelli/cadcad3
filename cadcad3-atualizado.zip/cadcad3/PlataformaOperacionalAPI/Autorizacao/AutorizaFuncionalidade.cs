﻿using Microsoft.AspNetCore.Authorization;

namespace PlataformaOperacionalAPI.Autorizacao
{
    public class AutorizaFuncionalidade : IAuthorizationRequirement
    {
    }
}
