﻿using Microsoft.AspNetCore.Authorization;
using PlataformaOperacional.Application.Service.Interface;

namespace PlataformaOperacionalAPI.Autorizacao
{
    public class AutorizacaoPorFuncionalidade : AuthorizationHandler<AutorizaFuncionalidade>
    {
        private readonly IPlataformaOperacionalService _plataformaService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public AutorizacaoPorFuncionalidade(IPlataformaOperacionalService plataformaService, IHttpContextAccessor httpContextAccessor)
        {
            _plataformaService = plataformaService;
            _httpContextAccessor = httpContextAccessor;
        }

        protected override async Task<Task> HandleRequirementAsync(AuthorizationHandlerContext context, AutorizaFuncionalidade requirement)
        {
            var endpoint = IdentificaEndpoint();

            if (await _plataformaService.VerificaFuncionalidadeAutorizadaAsync(endpoint))//Logica de validacao
            {
                context.Succeed(requirement);
            }

            return Task.CompletedTask;
        }

        private string IdentificaEndpoint()
        {
            var parametros = _httpContextAccessor.HttpContext.GetEndpoint().DisplayName;

            var index = parametros.LastIndexOf('.');

            var endpoint = parametros.Substring(index + 1);

            return endpoint.Substring(0, endpoint.IndexOf("(") - 1);
        }
    }
}
