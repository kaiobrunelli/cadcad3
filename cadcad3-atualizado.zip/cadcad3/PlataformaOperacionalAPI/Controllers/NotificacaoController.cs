﻿using Microsoft.AspNetCore.Mvc;
using PlataformaNotificacao.Application.Interface;
using PlataformaNotificacao.Domain.DTO;

namespace PlataformaOperacionalAPI.Controllers;

[ApiController]
[Route("api/notificacao")]
[Produces("application/json")]
public class ControladorNotificacao(INotificacaoService servico) : ControllerBase
{
    /// <summary>Retorna as notificações do usuário com estado de leitura.</summary>
    [HttpGet("matricula")]
    [ProducesResponseType(typeof(List<NotificacaoDto>), 200)]
    public async Task<IActionResult> ObterNotificacaoPorMatricul([FromQuery] string matricula)
    {
        if (string.IsNullOrWhiteSpace(matricula))
            return BadRequest("Matricula é obrigatório.");

        var lista = await servico.ObterNotificacaoPorMatriculaAsync(matricula);
        return Ok(lista);
    }

    /// <summary>Retorna a contagem de notificações não lidas (badge do sino).</summary>
    [HttpGet("nao-lidas/total")]
    [ProducesResponseType(typeof(int), 200)]
    public async Task<IActionResult> ContarNaoLidas([FromQuery] string usuarioId)
    {
        if (string.IsNullOrWhiteSpace(usuarioId))
            return BadRequest("usuarioId é obrigatório.");

        var total = await servico.ContarNaoLidasAsync(usuarioId);
        return Ok(total);
    }

    /// <summary>Marca uma notificação específica como lida.</summary>
    [HttpPut("{id:int}/lida")]
    [ProducesResponseType(200)]
    public async Task<IActionResult> MarcarLida(int id, [FromQuery] string usuarioId)
    {
        if (string.IsNullOrWhiteSpace(usuarioId))
            return BadRequest("usuarioId é obrigatório.");

        var ok = await servico.MarcarLidaAsync(id, usuarioId);
        return ok ? Ok(new { sucesso = true }) : NotFound();
    }

    /// <summary>Marca todas as notificações do usuário como lidas.</summary>
    [HttpPut("marcar-todas-lidas")]
    [ProducesResponseType(200)]
    public async Task<IActionResult> MarcarTodasLidas([FromQuery] string usuarioId)
    {
        if (string.IsNullOrWhiteSpace(usuarioId))
            return BadRequest("usuarioId é obrigatório.");

        await servico.MarcarTodasLidasAsync(usuarioId);
        return Ok(new { sucesso = true });
    }

    /// <summary>Verifica se a API está online.</summary>
    [HttpGet("status")]
    public IActionResult ObterStatus() =>
        Ok(new { online = true, timestamp = DateTime.UtcNow });
}
