﻿using Azure;
using ChecklistContratacao.Domain.Dto;
using ChecklistContratacao.Domain.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using PlataformaOperacional.Application.Service;
using PlataformaOperacional.Application.Service.Interface;
using RedeCaixaUtilitario.Domain.Model;
using System.Diagnostics.Contracts;
using System.Reflection;
using Utilitarios.Model;

namespace PlataformaOperacionalAPI.Controllers
{
	[ApiController]
	[Route("/api/[Action]")]
    [Authorize(Policy = "AutorizaFuncionalidade")]

    public class ContratacaoController : ControllerBase
    {
        private readonly IContratacaoService _contratacaoService;
        private readonly IPlataformaOperacionalService _plataformaService;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public ContratacaoController(IContratacaoService contratacaoService, IPlataformaOperacionalService plataformaService, IHttpContextAccessor httpContextAccessor)
        {
            _contratacaoService = contratacaoService;
            _plataformaService = plataformaService;
            _httpContextAccessor = httpContextAccessor;
        }

        [HttpGet]
        public async Task<IActionResult> ConsultaContratosParaConformidade()
        {
            var trilha = _plataformaService
               .GerarTrilhaDeAuditoria(
             "Consultar",
             $"Consultou contratos de checklist de contratação para conformidade.",
             "Solicitado",
                _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
            );

            try
            {

                var response = await _contratacaoService.ConsultaContratosParaConformidadeAsync();
                if (response is null) { throw new Exception("Nenhum contrato encontrado."); }
                trilha.Resposta = $"ACATADO";
                await _plataformaService.SaveAsync();
                return Ok(response);
            }       
		
		
			catch (Exception ex)
			{
				//var errorJson = new ErrorMessageJson(ex.Message);
				trilha.Resposta = $"ERRO : {ex.Message}";
				await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }
		}

        [HttpGet]
        public async Task<IActionResult> ConsultaChecklistContratacaoPorContrato(string contrato)
        {
            var trilha = _plataformaService
             .GerarTrilhaDeAuditoria(
              "Consultar",
              $"Consultou checklist de contratação do contrato : {contrato}",
              "Solicitado",
              _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
              );

            try
            {
                var contratos = await _contratacaoService.ConsultarChecklist(contrato);
                if (contratos is null) { throw new Exception("Nenhum contrato encontrado."); }

                trilha.Resposta = $"ACATADO";
                await _plataformaService.SaveAsync();
                return Ok(contratos);
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }

        }

        [HttpGet]
        public async Task<IActionResult> CarregaChecklistContratacao()
        {
            var trilha = _plataformaService
               .GerarTrilhaDeAuditoria(
             "Carregar",
             $"Carregou checklist de contratação dos contratos",
             "Solicitado",
                _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
            );

            try
            {
                await _contratacaoService.CarregarChecklistContratosCarregados();

                trilha.Resposta = $"ACATADO";
                await _plataformaService.SaveAsync();
                return Ok("Contratos carregados com sucesso.");
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }
        }

        [HttpGet]
        public async Task<IActionResult> ConsultaTiposDeResposta()
        {
            var trilha = _plataformaService
                  .GerarTrilhaDeAuditoria(
                "Consultar",
                $"Consultou respostas de checklist de contratação.",
                "Solicitado",
                   _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
               );
            try
            {
                var response = await _contratacaoService.ConsultarRespostasChecklist();
                if (response is null) { throw new Exception("Nenhum resposta encontrada."); }
                trilha.Resposta = $"ACATADO";
                await _plataformaService.SaveAsync();
                return Ok(response);
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }
        }

        [HttpPost]
        public async Task<IActionResult> AtualizarChecklist(RespostaChecklist resposta)
        {
            var trilha = _plataformaService
               .GerarTrilhaDeAuditoria(
             "Atualizar",
             $"Atualizou checklist de contratação.",
             "Solicitado",
                _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
            );

            try
            {
                await _contratacaoService.AtualizarChecklist(resposta);
                trilha.Resposta = $"ACATADO";
                await _plataformaService.SaveAsync();
                return Ok("Resposta alterada com sucesso.");
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }
        }
        [HttpGet]
        public async Task<IActionResult> ConsultarTomadores()
        {
            var trilha = _plataformaService
              .GerarTrilhaDeAuditoria(
            "Consultar",
            $"Consultou contratos de checklist de contratação para conformidade.",
            "Solicitado",
               _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
           );

            try
            {
                var response = await _contratacaoService.ConsultarTomadores();
                if (response is null) { throw new Exception("Nenhum tomador encontrado."); }
                trilha.Resposta = $"ACATADO";
                await _plataformaService.SaveAsync();
                return Ok(response);
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }
        }


        [HttpGet]
        public async Task<IActionResult> ConsultarResumoTomadores()
        {
            var trilha = _plataformaService
              .GerarTrilhaDeAuditoria(
            "Consultar",
            $"Consultar resulto tomador  de checklist de contratação.",
            "Solicitado",
               _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
           );

            try
            {
                var response = await _contratacaoService.ConsultarResumosTomador();
                if (response is null) { throw new Exception("Nenhum resumo tomador encontrado."); }
                trilha.Resposta = $"ACATADO";
                await _plataformaService.SaveAsync();
                return Ok(response);
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }
        }


        [HttpGet]
        public async Task<IActionResult> ConsultarResumoTodosContratos()
        {
            {
                var trilha = _plataformaService
                  .GerarTrilhaDeAuditoria(
                "Consultar",
                $"Consultou resumo todos contratos do checklist de contratação.",
                "Solicitado",
                   _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
               );

                try
                {
                    var response = await _contratacaoService.ConsultarResumoTodosContratos();
                    if (response is null) { throw new Exception("Nenhum resumo todos contratos encontrado."); }
                    trilha.Resposta = $"ACATADO";
                    await _plataformaService.SaveAsync();
                    return Ok(response);
                }
                catch (Exception ex)
                {
                    trilha.Resposta = $"ERRO : {ex.Message}";
                    await _plataformaService.SaveAsync();
                    return BadRequest(new ProblemDetails { Detail = ex.Message });
                }
            }
        }

        [HttpGet]
        public async Task<IActionResult> ConsultarResumoContratosPorTomador(string coTomador)
        {
            var trilha = _plataformaService
              .GerarTrilhaDeAuditoria(
            "Consultar",
            $"Consultou resumo tomador código {coTomador} do checklist de contratação.",
            "Solicitado",
               _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
           );

            try
            {
                var response = await _contratacaoService.ConsultarResumoTomadorPorCoTomadorAsync(coTomador);
                if (response is null) { throw new Exception("Nenhum resumo código tomador encontrado."); }
                trilha.Resposta = $"ACATADO";
                await _plataformaService.SaveAsync();
                return Ok(response);
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }
        }

        [HttpGet]
        public async Task<IActionResult> ConsultarResumoGeralChecklist()
        {
            var trilha = _plataformaService
              .GerarTrilhaDeAuditoria(
            "Consultar",
            $"Consultou resumo checklist de contratação.",
            "Solicitado",
               _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
           );
            try
            {
                var response = await _contratacaoService.ConsultarResumoGeralChecklist();
                if (response is null) { throw new Exception("Nenhum resumo geral encontrado."); }
                trilha.Resposta = $"ACATADO";
                await _plataformaService.SaveAsync();
                return Ok(response);
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }
        }

        [HttpGet]
        public async Task<IActionResult> ConsultarRessalvasPorContrato(string contrato)
        {
            var trilha = _plataformaService
              .GerarTrilhaDeAuditoria(
            "Consultar",
            $"Consultou ressalva por contrato {contrato} do checklist de contratação.",
            "Solicitado",
               _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
           );
            try
            {
                var usuario = _plataformaService.IdentificarUsuario();
                var response = await _contratacaoService.ConsultarRessalvaPorContratoAsync(contrato);
                if (response is null) { throw new Exception("Nenhuma resssalva do contrato encontrado."); }
                trilha.Resposta = $"ACATADO";
                await _plataformaService.SaveAsync();
                return Ok(response);
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }
        }

        [HttpPost]
        public async Task<IActionResult> CadastrarRessalva(CreateRessalvaChecklistDto ressalvaDto)
        {
            var trilha = _plataformaService
              .GerarTrilhaDeAuditoria(
            "Cadastrar",
            $"Cadastrou ressalva:'{ressalvaDto.Observacao}' no contrato {ressalvaDto.Contrato}.",
            "Solicitado",
               _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
           );

            try
            {
                await _contratacaoService.CadastrarRessalvaAsync(ressalvaDto);
                trilha.Resposta = $"ACATADO";
                await _plataformaService.SaveAsync();
                return Ok("Cadastro realizado com sucesso.");
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }
        }

        [HttpPost]
        public async Task<IActionResult> AtualizarRessalva(RespostaRessalva ressalva)
        {
            {
                var trilha = _plataformaService
                  .GerarTrilhaDeAuditoria(
                "Atualizar",
				$"Atualizou ressalva:'{ressalva.IdRessalva}', observação: {ressalva.ObservacaoTratamento}",
				"Solicitado",
                   _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
               );

                try
                {
                    //var usuario = _plataformaService.IdentificarUsuario();
                    await _contratacaoService.AtualizarRessalvaAsync(ressalva);
                    trilha.Resposta = $"ACATADO";
                    await _plataformaService.SaveAsync();
                    return Ok("Ressalva atualizada com sucesso.");
                }
                catch (Exception ex)
                {
                    trilha.Resposta = $"ERRO : {ex.Message}";
                    await _plataformaService.SaveAsync();
                    return BadRequest(new ProblemDetails { Detail = ex.Message });
                }
            }
        }


        [HttpDelete]
        public async Task<IActionResult> DesativarRessalva(int idRessalva)
        {
            {
                var trilha = _plataformaService
                  .GerarTrilhaDeAuditoria(
                "Desativar",
                $"Desativou ressalva id {idRessalva} do checklist de contratação.",
                "Solicitado",
                _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
               );
                try
                {
                    await _contratacaoService.DesativarRessalvaAsync(idRessalva);
                    trilha.Resposta = $"ACATADO";
                    await _plataformaService.SaveAsync();
                    return Ok("Ressalva excluída com sucesso.");
                }
                catch (Exception ex)
                {
                    trilha.Resposta = $"ERRO : {ex.Message}";
                    await _plataformaService.SaveAsync();
                    return BadRequest(new ProblemDetails { Detail = ex.Message });
                }
            }
        }

        [HttpPost]
        public async Task<IActionResult> FinalizarChecklistContrato([FromBody] string coContrato)
        {
            {
                var trilha = _plataformaService
                  .GerarTrilhaDeAuditoria(
                "Finalizar",
                $"Finalizou contrato {coContrato} do checklist de contratação.",
                "Solicitado",
                _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
               );
                try
                {
                    await _contratacaoService.FinalizaChecklistContrato(coContrato);
                    trilha.Resposta = $"ACATADO";
                    await _plataformaService.SaveAsync();
                    return Ok("Checklist Finalizado com sucesso.");
                }
                catch (Exception ex)
                {
                    trilha.Resposta = $"ERRO : {ex.Message}";
                    await _plataformaService.SaveAsync();
                    return BadRequest(new ProblemDetails { Detail = ex.Message });
                }
            }
        }

		[HttpPost]
		public async Task<IActionResult> CancelarFinalizacaoContrato([FromBody] string coContrato)
		{
			{
				var trilha = _plataformaService
				  .GerarTrilhaDeAuditoria(
				"Cancelar finalização",
				$"Cancelou a finalização do contrato {coContrato} do checklist de contratação.",
				"Solicitado",
				_httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
			   );
				try
				{
					await _contratacaoService.CancelarFinalizacaoChecklistContrato(coContrato);
					trilha.Resposta = $"ACATADO";
					await _plataformaService.SaveAsync();
					return Ok("Finalização do Checklist cancelada com sucesso.");
				}
				catch (Exception ex)
				{
					trilha.Resposta = $"ERRO : {ex.Message}";
					await _plataformaService.SaveAsync();
					return BadRequest(new ProblemDetails { Detail = ex.Message });
				}
			}
		}


	}
}
