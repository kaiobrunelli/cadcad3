﻿using EntradaDeDados.Domain.Dto;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PlataformaOperacional.Application.Service;
using PlataformaOperacional.Application.Service.Interface;
using PlataformaOperacionalAPI.Requisicoes;

namespace PlataformaOperacionalAPI.Controllers
{
	[ApiController]
	[Route("/api/[Action]")]
	[Authorize(Policy = "AutorizaFuncionalidade")]
	public class MonitoramentoController : ControllerBase
	{
		private readonly IMonitoramentoService _monitoramentoService;
		private readonly IPlataformaOperacionalService _plataformaService;
		private readonly IHttpContextAccessor _httpContextAccessor;

		public MonitoramentoController(IHttpContextAccessor httpContextAccessor, IMonitoramentoService monitoramentoService, IPlataformaOperacionalService plataformaService)
		{
			_httpContextAccessor = httpContextAccessor;
			_monitoramentoService = monitoramentoService;
			_plataformaService = plataformaService;
		}

		#region Consulta CRF

		[HttpPost]
		public async Task<IActionResult> RealizarOperacaoCrf([FromBody] PedidoAutomacaoDto solicitacao)
		{
			var trilha = _plataformaService
				.GerarTrilhaDeAuditoria(
			"Alterar",
					$"Realizar todas as consultas de regularidade do CRF.",
					"Solicitado",
					_httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
					);
			try
			{

				var pedido = _plataformaService
				.GerarPedidoDeAutomacao(this.GetType().Name.Replace("Service", ""), IdentificaEndpoint(), solicitacao.Senha, false);

				await _monitoramentoService.RealizarOperacaoCrf(pedido);
				trilha.Resposta = "ACATADO";
				await _plataformaService.SaveAsync();
				return Ok("Consultas realizadas com sucesso.");
			}
			catch (Exception ex)
			{
				trilha.Resposta = $"ERRO : {ex.Message}";
				await _plataformaService.SaveAsync();
				return BadRequest(new ProblemDetails { Detail = ex.Message });
			}
		}

		[HttpGet]
		public async Task<IActionResult> ConsultarCrfAtual()
		{
			var trilha = _plataformaService
				.GerarTrilhaDeAuditoria(
			"Consultar",
					$"Consultar pesquisas de CRF do dia atual",
					"Solicitado",
					_httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
					);
			try
			{
				var contratos = _monitoramentoService.ConsultarCrfAtual();
				trilha.Resposta = "ACATADO";
				await _plataformaService.SaveAsync();
				return Ok(contratos);
			}
			catch (Exception ex)
			{
				trilha.Resposta = $"ERRO : {ex.Message}";
				await _plataformaService.SaveAsync();
				return BadRequest(new ProblemDetails { Detail = ex.Message });
			}

		}
		[HttpGet]
		public async Task<IActionResult> ConsultarCrfAnteriores(DateTime data)
		{
			var trilha = _plataformaService
				.GerarTrilhaDeAuditoria(
			"Consultar",
					$"Consultar pesquisas de CRF dos dias anteriores",
					"Solicitado",
					_httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
					);
			try
			{
				var contratos = _monitoramentoService.ConsultarCrfAnteriores(data);
				trilha.Resposta = "ACATADO";
				await _plataformaService.SaveAsync();
				return Ok(contratos);
			}
			catch (Exception ex)
			{
				trilha.Resposta = $"ERRO : {ex.Message}";
				await _plataformaService.SaveAsync();
				return BadRequest(new ProblemDetails { Detail = ex.Message });
			}

		}

        #endregion

        #region Entrada de Dados
        [HttpPost]
        public async Task<IActionResult> IncluirDados(List<EntradaDadosDto> entradas)
        {
			var trilha = _plataformaService.GerarTrilhaDeAuditoria(
					"Incluir", $"Incluir dados atualizados referentes ao SISFIN.", "Solicitado",
					_httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!);

			var result = await _monitoramentoService.IncluirEntradaDados(entradas);
			trilha.Resposta = result.IsValid ? "ACATADO" : $"ERRO:" + result.Notifications?.FirstOrDefault()?.Message;

            await _plataformaService.SaveAsync();

            return result.IsValid ?
                Ok("Dados incluídos com sucesso.") :
                BadRequest(new { success = false, notifications = result.NotificationsList });
        }

        [HttpGet]
        public async Task<IActionResult> ConsultarUltimoControle()
        {
			var trilha = _plataformaService
				.GerarTrilhaDeAuditoria(
			"Consultar",
					$"Consultar último controle incluído.",
					"Solicitado",
					_httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
					);

			try 
			{
				var result = await _monitoramentoService.ConsultarUltimoControle();
				trilha.Resposta = "ACATADO";
				await _plataformaService.SaveAsync();
				return Ok(result);
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }
        }
        #endregion

        private string IdentificaEndpoint()
		{
			var parametros = _httpContextAccessor.HttpContext.GetEndpoint().DisplayName;

			var index = parametros.LastIndexOf('.');

			var endpoint = parametros.Substring(index + 1);

			return endpoint.Substring(0, endpoint.IndexOf("(") - 1);
		}
	}
}
