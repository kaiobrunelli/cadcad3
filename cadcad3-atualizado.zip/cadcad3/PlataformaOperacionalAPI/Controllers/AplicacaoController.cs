﻿using ControleAnaliseDesembolso.Application.Dtos.Request;
using ControleAnaliseDesembolso.Application.Dtos.Response;
using ControleAnaliseDesembolso.Application.Interface;
using ControleAnaliseDesembolso.Interface;
using Desembolsos.Domain.Dto;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PlataformaOperacional.Application.Service.Interface;
using PlataformaOperacionalAPI.Requisicoes;
using PreditorDeDesembolso.Domain.Dto;
using System.Net;
using Utilitarios.Model;
using ValidadorDeArquivosApi.Application.DTOs;
using ValidadorDeArquivosApi.Application.Mappers;
using ValidadorDeArquivosApi.Core.Relatorio;

namespace PlataformaOperacionalAPI.Controllers
{
    [ApiController]
    [Route("/api/[Action]")]
    //[Authorize(Policy = "AutorizaFuncionalidade")]
    public class AplicacaoController : ControllerBase
    {
        private readonly IAplicacaoService _aplicacaoService;
        private readonly IPlataformaOperacionalService _plataformaService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IWebHostEnvironment _environment;
        public AplicacaoController(IAplicacaoService aplicacaoService,
            IPlataformaOperacionalService plataformaService, 
            IHttpContextAccessor httpContextAccessor, 
            IWebHostEnvironment environment,
            IControleAnaliseDesembolsoService servico,
            IFichaPedidoDesembolsoService servicoFpd)
        {
            _aplicacaoService = aplicacaoService;
            _plataformaService = plataformaService;
            _httpContextAccessor = httpContextAccessor;
            _environment = environment;
        }
    
    
        #region Saldo Residual
        [HttpGet]
        public async Task<IActionResult> LocalizarContratosParaAnalise()
        {
            var trilha = _plataformaService
                .GerarTrilhaDeAuditoria(
            "Consultar",
                    $"Consultar contratos para análise manual do saldo residual",
                    "Solicitado",
                    _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                    );
            try
            {
                var contratos = _aplicacaoService.LocalizarContratosParaAnalise();
                trilha.Resposta = "ACATADO";
                await _plataformaService.SaveAsync();
                return Ok(contratos);
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }

        }
        [HttpGet]
        public async Task<IActionResult> LocalizarContratosNaoProcessados()
        {
            var trilha = _plataformaService
                .GerarTrilhaDeAuditoria(
            "Consultar",
                    $"Consultar contratos não processados pelo saldo residual",
                    "Solicitado",
                    _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                    );

            try
            {
                var contratos = _aplicacaoService.LocalizarContratosNaoProcessados();
                trilha.Resposta = "ACATADO";
                await _plataformaService.SaveAsync();
                return Ok(contratos);
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }

        }
        [HttpGet]
        public async Task<IActionResult> LocalizarSituacaoOperacoes()
        {
            var trilha = _plataformaService
                .GerarTrilhaDeAuditoria(
            "Consultar",
                    $"Consultar situaçõa dos contratos do saldo residual",
                    "Solicitado",
                    _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                    );

            try
            {
                var contratos = _aplicacaoService.LocalizarSituacaoOperacoes();
                trilha.Resposta = "ACATADO";
                await _plataformaService.SaveAsync();
                return Ok(contratos);
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }
        }
        [HttpPost]
        public async Task<IActionResult> RealizarOperacaoSaldoResidual([FromBody] string senha)
        {
            var trilha = _plataformaService
                .GerarTrilhaDeAuditoria(
            "Alterar",
                    $"Realizar todas as operações pendente do Saldo Residual",
                    "Solicitado",
                    _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                    );
            try
            {
                await _aplicacaoService.RealizarOperacaoSaldoResidual(senha);
                trilha.Resposta = "ACATADO";
                await _plataformaService.SaveAsync();
                return Ok("Contratos processados com sucesso.");
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }
        }
        [HttpPost]
        public async Task<IActionResult> ProcessarContratoManual(RequisicaoIdDesc requisicao)
        {
            var trilha = _plataformaService
                .GerarTrilhaDeAuditoria(
            "Alterar",
                    $"Realizar operação do Saldo Residual manual do contrato: {requisicao.CoOperacao}",
                    "Solicitado",
                    _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                    );
            try
            {
                _aplicacaoService.ProcessarContratoManual(requisicao.CoOperacao, requisicao.Desc);
                trilha.Resposta = "ACATADO";
                await _plataformaService.SaveAsync();
                return Ok("Contrato processado com sucesso.");
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }
        }
        #endregion

        #region Esteira OAF
        [HttpGet]
        public async Task<IActionResult> LocalizarDesembolsosEsteiraOAF(DateTime date)
        {
            var trilha = _plataformaService
                .GerarTrilhaDeAuditoria(
            "Consultar",
                    $"Consultar desembolsos da esteira de desembolso dos outros agentes financeiros",
                    "Solicitado",
                    _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                    );
            try
            {
                var contratos = _aplicacaoService.ConsultarDesembolsoOAF(date);
                trilha.Resposta = "ACATADO";
                await _plataformaService.SaveAsync();
                return Ok(contratos);
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }

        }
        [HttpPost]
        public async Task<IActionResult> ExpurgarDesembolsosOAF([FromBody] ExpurgarDesembolsoDto request)
        {
            var trilha = _plataformaService
                .GerarTrilhaDeAuditoria(
            "Consultar",
                    $"Expurgar desembolsos da esteira de desembolso dos outros agentes financeiros",
                    "Solicitado",
                    _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                    );
            try
            {
                _aplicacaoService.ExpurgarDesembolsosOAF(request.Fid, request.DeObservacao
);
                trilha.Resposta = "ACATADO";
                await _plataformaService.SaveAsync();
                return Ok("Desembolsos expurgados");
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }

        }
        [HttpPost]
        public async Task<IActionResult> ResetarDesembolsosEsteiraOAF([FromBody] string fid)
        {
            var trilha = _plataformaService
                .GerarTrilhaDeAuditoria(
            "Consultar",
                    $"Resetar desembolsos da esteira de desembolso dos outros agentes financeiros",
                    "Solicitado",
                    _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                    );
            try
            {
                _aplicacaoService.ResetarDesembolsosOAF(fid);
                trilha.Resposta = "ACATADO";
                await _plataformaService.SaveAsync();
                return Ok("Desembolsos resetados.");
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }

        }
        #endregion

        #region Preditor de Desembolso
        [HttpGet]
        [ProducesResponseType(typeof(ReadControlePreditorDeDesembolsoDto), (int)HttpStatusCode.OK)]
        public async Task<IActionResult> ConsultarDadosDoPreditorDeDesembolso()
        {
            var trilha = _plataformaService
                .GerarTrilhaDeAuditoria(
            "Consultar",
                    $"Consultar dados do preditor de desembolso",
                    "Solicitado",
                    _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                    );

            try
            {
                var contratos = _aplicacaoService.ConsultarDadosDoPreditorDeDesembolso();
                trilha.Resposta = "ACATADO";
                await _plataformaService.SaveAsync();
                return Ok(contratos);
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }

        }
        [HttpGet]
        public async Task<IActionResult> ConsultarPreditorAnaliticoPublico()
        {
            var trilha = _plataformaService
                .GerarTrilhaDeAuditoria(
            "Consultar",
                    $"Consultar dados do preditor de desembolso do setor publico",
                    "Solicitado",
                    _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                    );

            try
            {
                var contratos = _aplicacaoService.ConsultarPreditorAnaliticoPublico();
                trilha.Resposta = "ACATADO";
                await _plataformaService.SaveAsync();
                return Ok(contratos);
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }

        }
        [HttpGet]
        public async Task<IActionResult> ConsultarPreditorAnaliticoPrivado()
        {
            var trilha = _plataformaService
                .GerarTrilhaDeAuditoria(
            "Consultar",
                    $"Consultar dados do preditor de desembolso do setor privado",
                    "Solicitado",
                    _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                    );

            try
            {
                var contratos = _aplicacaoService.ConsultarPreditorAnaliticoPrivado();
                trilha.Resposta = "ACATADO";
                await _plataformaService.SaveAsync();
                return Ok(contratos);
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }

        }
        [HttpGet]
        public async Task<IActionResult> ConsultarRelatorioDeResultados()
        {
            var trilha = _plataformaService
                .GerarTrilhaDeAuditoria(
            "Consultar",
                    $"Consultar relatorio de resultados do preditor de desembolso",
                    "Solicitado",
                    _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                    );

            try
            {
                var relatorios = _aplicacaoService.ConsultarRelatorioDeResultados();
                trilha.Resposta = "ACATADO";
                await _plataformaService.SaveAsync();
                return Ok(relatorios);
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }

        }
        [HttpPost]
        public async Task<IActionResult> AtualizarPreditorAnaliticoPrivado([FromBody] ReadPreditorAnaliticoPrivadoDto dto)
        {
            var trilha = _plataformaService
                .GerarTrilhaDeAuditoria(
            "Consultar",
                    $"Atualizar valor efetivado do preditor de desembolso do setor privado",
                    "Solicitado",
                    _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                    );

            try
            {
                _aplicacaoService.AtualizarPreditorAnaliticoPrivado(dto);
                trilha.Resposta = "ACATADO";
                await _plataformaService.SaveAsync();
                return Ok("Valor efetivado alterado com sucesso.");
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }

        }
        [HttpPost]
        public async Task<IActionResult> AtualizarPreditorAnaliticoPublico([FromBody] ReadPreditorAnaliticoPublicoDto dto)
        {
            var trilha = _plataformaService
                .GerarTrilhaDeAuditoria(
            "Consultar",
                    $"Atualizar valor efetivado do preditor de desembolso do setor público",
                    "Solicitado",
                    _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                    );

            try
            {
                _aplicacaoService.AtualizarPreditorAnaliticoPublico(dto);
                trilha.Resposta = "ACATADO";
                await _plataformaService.SaveAsync();
                return Ok("Valor efetivado alterado com sucesso.");
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }

        }
        [HttpPost]
        public async Task<IActionResult> ResetarPreditorAnaliticoPrivado()
        {
            var trilha = _plataformaService
                .GerarTrilhaDeAuditoria(
            "Consultar",
                    $"Atualizar valor efetivado do preditor de desembolso do setor privado",
                    "Solicitado",
                    _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                    );

            try
            {
                _aplicacaoService.ResetarPreditorAnaliticoPrivado();
                trilha.Resposta = "ACATADO";
                await _plataformaService.SaveAsync();
                return Ok("Valor resetado com sucesso.");
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }

        }
        [HttpPost]
        public async Task<IActionResult> ResetarPreditorAnaliticoPublico()
        {
            var trilha = _plataformaService
                .GerarTrilhaDeAuditoria(
            "Consultar",
                    $"Atualizar valor efetivado do preditor de desembolso do setor público",
                    "Solicitado",
                    _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                    );

            try
            {
                _aplicacaoService.ResetarPreditorAnaliticoPublico();
                trilha.Resposta = "ACATADO";
                await _plataformaService.SaveAsync();
                return Ok("Valor resetado com sucesso.");
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }

        }
        [HttpPost]
        public async Task<IActionResult> FinalizarPreditorEnviarEmail()
        {
            var trilha = _plataformaService
                .GerarTrilhaDeAuditoria(
            "Consultar",
                    $"Finalizar preditor e enviar e-mail",
                    "Solicitado",
                    _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                    );

            try
            {
                _aplicacaoService.FinalizarPreditorEnviarEmail();
                trilha.Resposta = "ACATADO";
                await _plataformaService.SaveAsync();
                return Ok("Finalizado com sucesso.");
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }

        }
        [HttpGet]
        public async Task<IActionResult> ConsultarPreditorAutorizados()
        {
            var trilha = _plataformaService
                .GerarTrilhaDeAuditoria(
            "Consultar",
                    $"Consultar autorizados a operar o preditor de desembolso",
                    "Solicitado",
                    _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                    );
            try
            {
                var autorizados = _aplicacaoService.ConsultarPreditorAutorizados();
                trilha.Resposta = "ACATADO";
                await _plataformaService.SaveAsync();
                return Ok(autorizados);
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }
        }
        [HttpPost]
        public async Task<IActionResult> CadastrarPreditorAutorizado([FromBody] CreatePreditorAutorizadosDto cadastro)
        {
            var trilha = _plataformaService
                .GerarTrilhaDeAuditoria(
            "Cadastro",
                    $"Cadastrar autorizado a operar o preditor de desembolso",
                    "Solicitado",
                    _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                    );
            try
            {
                _aplicacaoService.CadastrarPreditorAutorizado(cadastro);
                trilha.Resposta = "ACATADO";
                await _plataformaService.SaveAsync();
                return Ok("Operador autorizado.");
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }
        }
        [HttpPost]
        public async Task<IActionResult> DesabilitarPreditorAutorizado([FromBody] string matricula)
        {
            var trilha = _plataformaService
                .GerarTrilhaDeAuditoria(
            "Alterar",
                    $"Desabilitar autorizado a operar o preditor de desembolso",
                    "Solicitado",
                    _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                    );
            try
            {
                _aplicacaoService.DesabilitarPreditorAutorizado(matricula);
                trilha.Resposta = "ACATADO";
                await _plataformaService.SaveAsync();
                return Ok("Operador desabilitado.");
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }
        }
        [HttpPost]
        public async Task<IActionResult> CadastrarEventual([FromBody] string matricula)
        {
            var trilha = _plataformaService
                .GerarTrilhaDeAuditoria(
            "Alterar",
                    $"Cadastrar eventual autorizado a operar o preditor de desembolso",
                    "Solicitado",
                    _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                    );
            try
            {
                _aplicacaoService.CadastrarEventual(matricula);
                trilha.Resposta = "ACATADO";
                await _plataformaService.SaveAsync();
                return Ok("Eventual cadastrado.");
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }
        }
        [HttpPost]
        public async Task<IActionResult> RemoverEventual([FromBody] string matricula)
        {
            var trilha = _plataformaService
                .GerarTrilhaDeAuditoria(
            "Alterar",
                    $"Remover eventual autorizado a operar o preditor de desembolso",
                    "Solicitado",
                    _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                    );
            try
            {
                _aplicacaoService.RemoverEventual(matricula);
                trilha.Resposta = "ACATADO";
                await _plataformaService.SaveAsync();
                return Ok("Eventual removido.");
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }
        }
        [HttpGet]
        public async Task<IActionResult> ConsultarEmailPreditor()
        {
            var trilha = _plataformaService
                .GerarTrilhaDeAuditoria(
            "Consultar",
                    $"Consultar e-mails cadastrados do preditor de desembolso",
                    "Solicitado",
                    _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                    );
            try
            {
                var autorizados = _aplicacaoService.ConsultarEmailPreditor();
                trilha.Resposta = "ACATADO";
                await _plataformaService.SaveAsync();
                return Ok(autorizados);
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }
        }
        [HttpPost]
        public async Task<IActionResult> CadastrarEmailPreditor([FromBody] CreateDestinatarioEmailPreditorDeDesembolsoDto destinatarioDto)
        {
            var trilha = _plataformaService
                .GerarTrilhaDeAuditoria(
            "Cadastro",
                    $"Cadastrar e-mail para o preditor de desembolso",
                    "Solicitado",
                    _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                    );
            try
            {
                _aplicacaoService.CadastrarEmailPreditor(destinatarioDto);
                trilha.Resposta = "ACATADO";
                await _plataformaService.SaveAsync();
                return Ok("E-mail cadastrado.");
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }
        }
        [HttpPost]
        public async Task<IActionResult> RemoverEmailPreditor([FromBody] int coDestinatario)
        {
            var trilha = _plataformaService
                .GerarTrilhaDeAuditoria(
            "Alterar",
                    $"Remover e-mail do preditor de desembolso",
                    "Solicitado",
                    _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                    );
            try
            {
                _aplicacaoService.RemoverEmailPreditor(coDestinatario);
                trilha.Resposta = "ACATADO";
                await _plataformaService.SaveAsync();
                return Ok("E-mail removido.");
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }
        }
        #endregion

        #region Desembolsos

        [HttpPost]
        public async Task<IActionResult> ProcessarDesembolsos([FromBody] string senha)
        {
            var result = new ServiceResult();

            try
            {
                var trilha = _plataformaService.GerarTrilhaDeAuditoria(
                    "Processar", $"Processar movimentações de desembolsos do dia : {DateOnly.FromDateTime(DateTime.Now)}",
                        "Solicitado",
                        _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                        );

                var pedido = _plataformaService
                    .GerarPedidoDeAutomacao(this.GetType().Name.Replace("Service", ""), IdentificaEndpoint(), senha, false);

                result = await _aplicacaoService.ProcessarDesembolsos(pedido, new CancellationToken());

                trilha.Resposta = result.IsValid
                    ? "ACATADO"
                    : $"ERRO: {string.Join("; ", result.Notifications.Select(n => n.Message))}";

                await _plataformaService.SaveAsync();
            }
            catch (Exception ex)
            {
                result.AddNotification($"Erro geral", ex.Message);
                return BadRequest(new { success = false, notifications = result.NotificationsList });
            }

            return result.IsValid ?
                Ok("Desembolsos incluídos com sucesso.") :
                BadRequest(new { success = false, notifications = result.NotificationsList });
        }

        [HttpPost]
        public async Task<IActionResult> ProcessarDesembolsosBaixa(DesembolsoAutomacaoDadosDto automacaoDados)
        {
            var result = new ServiceResult();

            try
            {
                var trilha = _plataformaService.GerarTrilhaDeAuditoria(
                    "Processar", $"Processar baixas de DRPs de desembolsos do dia : {DateOnly.FromDateTime(DateTime.Now)}",
                        "Solicitado",
                        _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                        );

                var pedido = _plataformaService
                    .GerarPedidoDeAutomacao(
                        this.GetType().Name.Replace("Service", ""), 
                        IdentificaEndpoint(), 
                        automacaoDados.Senha, 
                        false);

                result = await _aplicacaoService.ProcessarDesembolsosBaixa(
                    pedido, 
                    automacaoDados.ControlesBaixa 
                    ?? throw new ArgumentNullException("Lista de controles a serem baixados não pode ser nula."), 
                    new CancellationToken());

                trilha.Resposta = result.IsValid
                    ? "ACATADO"
                    : $"ERRO: {string.Join("; ", result.Notifications.Select(n => n.Message))}";

                await _plataformaService.SaveAsync();
            }
            catch (Exception ex)
            {
                result.AddNotification($"Erro geral", ex.Message);
                return BadRequest(new { success = false, notifications = result.NotificationsList });
            }

            return result.IsValid ?
                Ok("DRPs baixadas com sucesso.") :
                BadRequest(new { success = false, notifications = result.NotificationsList });
        }

        [HttpPost]
        public async Task<IActionResult> CriarFluxoDesembolsos(List<DesembolsoFluxoDto> desembolsos)
        {
            var result = new ServiceResult();

            try
            {
                var trilha = _plataformaService.GerarTrilhaDeAuditoria(
                    "Criar", $"Criando novo fluxo de execução para data : {DateOnly.FromDateTime(DateTime.Now)}",
                        "Solicitado",
                        _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                        );

                result = await _aplicacaoService.CriarFluxoExecucao(desembolsos);

                trilha.Resposta = result.IsValid ?
                    "ACATADO" :
                    $"ERRO:" + result.Notifications.ToString();

                await _plataformaService.SaveAsync();
            }
            catch (Exception ex)
            {
                result.AddNotification($"Erro geral", ex.Message);
                return BadRequest(new { success = false, notifications = result.NotificationsList });
            }

            return result.IsValid ?
                Ok("Fluxo criado com sucesso.") :
                BadRequest(new { success = false, notifications = result.NotificationsList });
        }

        [HttpPost]
        public async Task<IActionResult> CancelarFluxoDesembolsos([FromBody] int coFluxo)
        {
            var result = new ServiceResult();

            try
            {
                var trilha = _plataformaService.GerarTrilhaDeAuditoria(
                    "Cancelar", $"Cancelando fluxo de execução número {coFluxo}",
                        "Solicitado",
                        _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!);

                result = await _aplicacaoService.CancelarFluxoExecucao(coFluxo);

                trilha.Resposta = result.IsValid ?
                    "ACATADO" :
                    $"ERRO:" + result.Notifications.ToString();

                await _plataformaService.SaveAsync();
            }
            catch (Exception ex)
            {
                result.AddNotification($"Erro geral", ex.Message);
                return BadRequest(new { success = false, notifications = result.NotificationsList });
            }

            return result.IsValid ?
                Ok("Fluxo criado com sucesso.") :
                BadRequest(new { success = false, notifications = result.NotificationsList });
        }

        [HttpPost]
        public async Task<IActionResult> TratarDesembolsoManualmente(TratarDesembolso dadosTratar)
        {
            var result = new ServiceResult();

            try
            {
                var trilha = _plataformaService.GerarTrilhaDeAuditoria(
                    "Tratar", $"Tratando desembolso contrato {dadosTratar.NuContrato}, FID {dadosTratar.Fid} manualmente.",
                        "Solicitado",
                        _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!);

                result = await _aplicacaoService.TratarContratoManualmente(dadosTratar);

                trilha.Resposta = result.IsValid ?
                    "ACATADO" :
                    $"ERRO:" + result.Notifications.ToString();

                await _plataformaService.SaveAsync();
            }
            catch (Exception ex)
            {
                result.AddNotification($"Erro geral", ex.Message);
                return BadRequest(new { success = false, notifications = result.NotificationsList });
            }

            return result.IsValid ?
                Ok("Contrato tratado com sucesso.") :
                BadRequest(new { success = false, notifications = result.NotificationsList });
        }

        [HttpPost]
        public async Task<IActionResult> AtualizarListaDesembolsos()
        {

            var trilha = _plataformaService.GerarTrilhaDeAuditoria(
                "Atualizar", $"Atualizando lista de desembolsos.",
                    "Solicitado",
                    _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!);

            try
            {

                var quantidadeNovos = await _aplicacaoService.AtualizarContratosEsteira();

                trilha.Resposta = "ACATADO";

                await _plataformaService.SaveAsync();

                return Ok($"Quantidade de novos desembolsos: {quantidadeNovos}");

            }
            catch (Exception ex)
            {

                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }
        }

        [HttpGet]
        public async Task<IActionResult> ConsultarControlesExecucao()
        {
            var trilha = _plataformaService
                .GerarTrilhaDeAuditoria(
            "Consultar",
                    $"Consultar controles de execução",
                    "Solicitado",
                    _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                    );
            try
            {
                var controles = await _aplicacaoService.ConsultarControlesExecucao();
                trilha.Resposta = "ACATADO";
                await _plataformaService.SaveAsync();
                return Ok(controles);
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }
        }

        [HttpGet]
        public async Task<IActionResult> ConsultarControlesExecucaoPorMatricula()
        {
            var trilha = _plataformaService
                .GerarTrilhaDeAuditoria(
            "Consultar",
                    $"Consultar controles de execução vinculados ao usuário.",
                    "Solicitado",
                    _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                    );
            try
            {
                var controles = await _aplicacaoService.ConsultarControlesExecucaoPorMatricula();
                trilha.Resposta = "ACATADO";
                await _plataformaService.SaveAsync();
                return Ok(controles);
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }
        }

        [HttpGet]
        public async Task<IActionResult> ConsultarDesembolsosPendentes()
        {
            var trilha = _plataformaService
                .GerarTrilhaDeAuditoria(
            "Consultar",
                    $"Consultar movimentações pendentes para desembolsos",
                    "Solicitado",
                    _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                    );
            try
            {
                var desembolsosPendentes = await _aplicacaoService.ConsultarDesembolsosPendentes();
                trilha.Resposta = "ACATADO";
                await _plataformaService.SaveAsync();
                return Ok(desembolsosPendentes);
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }
        }

        [HttpGet]
        public async Task<IActionResult> ConsultarDesembolsosNaoSelecionados()
        {
            var trilha = _plataformaService
                .GerarTrilhaDeAuditoria(
            "Consultar",
                    $"Consultar desembolsos disponíveis para seleção",
                    "Solicitado",
                    _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                    );
            try
            {
                var desembolsosPendentes = await _aplicacaoService.ConsultarDesembolsosPendentes();
                trilha.Resposta = "ACATADO";
                await _plataformaService.SaveAsync();
                return Ok(desembolsosPendentes.Where(d => d.CoControleExecucao is null));
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }
        }

        [HttpGet]
        public async Task<IActionResult> ConsultarDesembolsosPorFluxo()
        {
            var trilha = _plataformaService
                .GerarTrilhaDeAuditoria(
            "Consultar",
                    $"Consultar desembolsos por fluxo",
                    "Solicitado",
                    _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                    );
            try
            {
                var controles = await _aplicacaoService.ConsultarControlesExecucaoPorMatricula();
                var controle = controles.FirstOrDefault();

                if (controle is null)
                {
                    throw new InvalidOperationException("Controle não pode ser nulo");
                }

                var desembolsosPendentes = await _aplicacaoService.ConsultarDesembolsosPendentes();

                var desembolsosExecucao = desembolsosPendentes
                    .Where((d) => d.CoControleExecucao == controle.CoControle)
                    .ToList();

                trilha.Resposta = "ACATADO";
                await _plataformaService.SaveAsync();
                return Ok(desembolsosExecucao);
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }
        }

        [HttpGet]
        public async Task<IActionResult> ConsultarDrpsPendentes()
        {
            var trilha = _plataformaService
                .GerarTrilhaDeAuditoria(
            "Consultar",
                    $"Consultar drps pendentes para emissão/baixa.",
                    "Solicitado",
                    _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                    );
            try
            {
                var controles = await _aplicacaoService.ConsultarControlesExecucaoPorMatricula();
                var controle = controles.FirstOrDefault();

                if (controle is null)
                {
                    throw new InvalidOperationException("Controle não pode ser nulo");
                }

                var drpsPendentes = await _aplicacaoService.ConsultarDrpsPendentes();
                var drpsPendentesFluxo = drpsPendentes.Where(drp => drp.CoControle == controle.CoControle);
                trilha.Resposta = "ACATADO";
                await _plataformaService.SaveAsync();
                return Ok(drpsPendentesFluxo);
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }
        }

        [HttpGet]
        public async Task<IActionResult> ConsultarDrpsFinalizadas()
        {
            var trilha = _plataformaService
                .GerarTrilhaDeAuditoria(
            "Consultar",
                    $"Consultar drps finalizadas.",
                    "Solicitado",
                    _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                    );
            try
            {
                var drpsFinalizadas = await _aplicacaoService.ConsultarDrpsFinalizadas();
                trilha.Resposta = "ACATADO";
                await _plataformaService.SaveAsync();
                return Ok(drpsFinalizadas);
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }
        }

        [HttpGet]
        public async Task<IActionResult> ConsultarDrpsParaBaixa()
        {
            var trilha = _plataformaService
                .GerarTrilhaDeAuditoria(
            "Consultar",
                    $"Consultar drps pendentes para baixa.",
                    "Solicitado",
                    _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                    );
            try
            {
                var drpsParaBaixa = await _aplicacaoService.ConsultarDrpsParaBaixa();
                trilha.Resposta = "ACATADO";
                await _plataformaService.SaveAsync();
                return Ok(drpsParaBaixa);
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }
        }

        [HttpGet]
        public async Task<IActionResult> ConsultarConfiguracoesCaixa()
        {
            var trilha = _plataformaService
                .GerarTrilhaDeAuditoria(
            "Consultar",
                    $"Consultar configurações sistema de desembolsos para AF CAIXA.",
                    "Solicitado",
                    _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                    );
            try
            {
                var configuracoes = await _aplicacaoService.ConsultarConfiguracoesCaixa();
                trilha.Resposta = "ACATADO";
                await _plataformaService.SaveAsync();
                return Ok(configuracoes);
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }
        }


        [HttpGet]
        public async Task<IActionResult> ConsultarConfiguracoesOutrosAfs()
        {
            var trilha = _plataformaService
                .GerarTrilhaDeAuditoria(
            "Consultar",
                    $"Consultar configurações sistema de desembolsos para demais agentes financeiros.",
                    "Solicitado",
                    _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                    );
            try
            {
                var configuracoes = await _aplicacaoService.ConsultarConfiguracoesOutrosAfs();
                trilha.Resposta = "ACATADO";
                await _plataformaService.SaveAsync();
                return Ok(configuracoes);
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }
        }

        [HttpGet]
        public async Task<IActionResult> ConsultarHistoricos()
        {
            var trilha = _plataformaService
                .GerarTrilhaDeAuditoria(
            "Consultar",
                    $"Consultar históricos para lançamento de desembolsos.",
                    "Solicitado",
                    _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                    );
            try
            {
                var historicos = await _aplicacaoService.ConsultarHistoricos();
                trilha.Resposta = "ACATADO";
                await _plataformaService.SaveAsync();
                return Ok(historicos);
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }
        }

        [HttpGet]
        public async Task<IActionResult> ConsultarPerfil()
        {
            var trilha = _plataformaService
                .GerarTrilhaDeAuditoria(
            "Consultar",
                    $"Consultar perfil de usuário.",
                    "Solicitado",
                    _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                    );
            try
            {
                var perfil = await _aplicacaoService.ConsultarPerfil();
                trilha.Resposta = "ACATADO";
                await _plataformaService.SaveAsync();
                return Ok(perfil);
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }
        }

        [HttpGet]
        public async Task<IActionResult> ConsultarResumoConsolidado()
        {
            var trilha = _plataformaService
                .GerarTrilhaDeAuditoria(
            "Consultar",
                    $"Consultar resumo consolidado de desembolsos.",
                    "Solicitado",
                    _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                    );
            try
            {
                var resumo = await _aplicacaoService.ConsultarResumoConsolidado();
                trilha.Resposta = "ACATADO";
                await _plataformaService.SaveAsync();
                return Ok(resumo);
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }
        }

        [HttpPost]
        [Consumes("multipart/form-data")]
        public async Task<IActionResult> ProcessarValidacao([FromForm] UploadRetificarArquivoRequest request)
        {
            RelatorioDeValidacao relatorio =
                await _aplicacaoService.ProcessarValidacaoAsync(request.Arqruivo);

            return Ok(relatorio);
        }

        [HttpPost]
        [Consumes("multipart/form-data")]
        [RequestSizeLimit(20 * 1024 * 1024)]
        public async Task<IActionResult> UploadArquivoValidado(
        [FromForm] UploadRetificarArquivoRequest request,
        CancellationToken cancellationToken)
        {
            if (request.Arqruivo is null || request.Arqruivo.Length == 0)
                return BadRequest("Arquivo não pode ser nulo.");

            var extension = Path.GetExtension(request.Arqruivo.FileName);

            if (!string.Equals(extension, ".txt", StringComparison.OrdinalIgnoreCase))
                return BadRequest("Formato de arquivo inválido.");

            RelatorioDeValidacao relatorio =
                await _aplicacaoService.ProcessarValidacaoAsync(request.Arqruivo);

            bool hasErrors = relatorio.Itens?
                .Any(item => item.Ocorrencias?
                    .Any(ocorrencia => ocorrencia.Gravidade == Gravidade.Erro) == true) == true;

            if (hasErrors)
            {
                return UnprocessableEntity(new
                {
                    message = "Arquivo contém erros de validação.",
                    relatorio
                });
            }

            var uploadFolder = Path.Combine(
                _environment.ContentRootPath,
                "Uploads",
                "Desembolsos");

            Directory.CreateDirectory(uploadFolder);


            var originalFileName = Path.GetFileName(request.Arqruivo.FileName);

            var destinationPath = Path.Combine(uploadFolder, originalFileName);


            await using var destinationStream = new FileStream(
                destinationPath,
                FileMode.CreateNew,
                FileAccess.Write,
                FileShare.None);

            await request.Arqruivo.CopyToAsync(destinationStream, cancellationToken);

            return Ok(new
            {
                message = "Arquivo salvo com sucesso.",
                originalFileName = Path.GetFileName(request.Arqruivo.FileName),
                savedFileName = originalFileName
            });
        }

        #endregion

        #region Helpers

        private string IdentificaEndpoint()
        {
            string parametros = _httpContextAccessor.HttpContext.GetEndpoint().DisplayName;

            int index = parametros.LastIndexOf('.');

            var endpoint = parametros.Substring(index + 1);

            return endpoint.Substring(0, endpoint.IndexOf("(") - 1);
        }

        #endregion

        #region Controle Analise Desembolso 
     
        [HttpGet]
        public async Task<ActionResult<List<DesembolsoResponse>>> ObterTodosDesembolsos()
            => Ok(await _aplicacaoService.ObterTodosDesembolsos());

        [HttpGet("{coDesembolso}")]
        public async Task<ActionResult<DesembolsoDetalheResponse>> ObterDetalheDesembolso([FromRoute] int coDesembolso)
            => Ok(await _aplicacaoService.ObterDetalheDesembolso(coDesembolso));

        [HttpGet("{id}/comentarios")]
        public async Task<ActionResult<List<ComentarioValidacaoResponse>>> ObterComentarios(int coDesembolso)
            => Ok(await _aplicacaoService.ObterComentarios(coDesembolso));

        [HttpPost]
        public async Task<IActionResult> AdicionarComentario(
            int coDesembolso, int coValidacao, [FromBody] ValidacaoRegistroRequest registro)
        {
            await _aplicacaoService.AdicionarComentario(new ValidacaoDesembolsoRequest
            {
                CoDesembolso = coDesembolso,
                CoValidacao = coValidacao,
                ValidacaoRegistro = registro,
            });
            return Ok();
        }

        [HttpPut("validacoes/comentarios/{comentarioId}")]
        public async Task<IActionResult> EditarComentario(
            int id, int numero, int comentarioId, [FromBody] EditarComentarioRequest request)
        {
            request.CoRegistroValidacao = comentarioId;
            await _aplicacaoService.EditarComentario(request);
            return Ok();
        }

        [HttpPut("{coComentario}")]
        public async Task<IActionResult> RemoverComentario(int coComentario, [FromQuery] string matriculaSolicitante)
        {
            await _aplicacaoService.RemoverComentario(coComentario, matriculaSolicitante);
            return Ok();
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Aprovar(int coDesembolso, [FromBody] AprovarDesembolsoRequest request)
        {
            await _aplicacaoService.AprovarDesembolso(coDesembolso, request);
            return Ok();
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> BaixarDRP(int coDesembolso)
        {
            await _aplicacaoService.BaixarDRP(coDesembolso);
            return Ok();
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Rejeitar(int coDesembolso, [FromBody] RejeitarDesembolsoRequest request)
        {
            await _aplicacaoService.RejeitarDesembolso(coDesembolso, request);
            return Ok();
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> VincularResponsavel(int coDesembolso, [FromBody] string? matriculaResponsavel)
        {
            await _aplicacaoService.VincularResponsavel(coDesembolso, matriculaResponsavel);
            return Ok();
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> RemoverResponsavel(int coDesembolso)
        {
            await _aplicacaoService.VincularResponsavel(coDesembolso, null);
            return Ok();
        }

        [HttpPost("{id}")]
        public async Task<IActionResult> Validar(int id)
        {
            await _aplicacaoService.ValidarDesembolso(id);
            return Ok();
        }

        [HttpPost]
        public async Task<IActionResult> ValidarTodosPendentes()
        {
            await _aplicacaoService.ValidarTodosPendentes();
            return Ok();
        }

        [HttpGet]
        public async Task<ActionResult<List<ValidacaoTemplateResponse>>> ObterValidacoesTemplate()
            => Ok(await _aplicacaoService.ObterValidacoesTemplate());

        [HttpGet]
        public async Task<ActionResult<PedidoConsultaContratoAfResponse>> SolicitarDadosFpd(
            [FromQuery] PedidoConsultaContratoAfRequest pedido)
            => Ok(await _aplicacaoService.SolicitarDadosFPD(pedido));

        [HttpPost]
        public async Task<IActionResult> CriarFichaPedidoDesembolso([FromBody] PedidoDesembolsoRequest request)
        {
            await _aplicacaoService.CriarFichaPedidoDesembolso(request);
            return Ok();
        }

        [HttpPut("{coFpd}")]
        public async Task<IActionResult> ReenviarFicha(int coFpd, [FromBody] PedidoDesembolsoRequest request)
        {
            await _aplicacaoService.ReenviarFichaPedidoDesembolso(coFpd, request);
            return Ok();
        }

        [HttpGet]
        public async Task<ActionResult<List<RegistroDrpResponse>>> ObterRegistrosDrp()
            => Ok(await _aplicacaoService.ObterRegistrosDrp());

        [HttpPut]
        public async Task<IActionResult> BaixarDrp([FromBody] BaixarDrpRequest request)
        {
            await _aplicacaoService.BaixarDrpEmLote(request);
            return Ok();
        }





        //[HttpGet]
        //public async Task<IActionResult> ConsultarDesembolso(int idFpd)
        //{               

        //    try
        //    {
        //    var response = await _aplicacaoService.ConsultarDesembolso(idFpd);
        //    return Ok(response);
        //    }
        //    catch (Exception ex)
        //    {
        //        await _plataformaService.SaveAsync();
        //        return BadRequest(new ProblemDetails { Detail = ex.Message });
        //    }
        //}

        //[HttpGet]
        //public async Task<IActionResult> SolicitarDadosFPD([FromQuery] PedidoConsultaContratoAfRequest Pedido)
        //{

        //    try
        //    {
        //        var contrato = await _aplicacaoService.SolicitarDadosFPD(Pedido);

        //        if (contrato is null)
        //        {
        //            return BadRequest("Contrato nulo");
        //        }   

        //        return Ok(contrato);
        //    }
        //    catch (Exception ex)
        //    {
        //        await _plataformaService.SaveAsync();
        //        return BadRequest(new ProblemDetails { Detail = ex.Message });
        //    }
        //}


        //[HttpPost]
        //public async Task<IActionResult> CriarFichaPedidoDesembolso(PedidoDesembolsoRequest request)
        //{
        //    try
        //    {
        //        await _aplicacaoService.CriarFichaPedidoDesembolso(request);

        //        return Ok("Pedido desembolso criado com sucesso!");
        //    }
        //    catch (Exception ex)
        //    {
        //        await _plataformaService.SaveAsync();

        //        return BadRequest(new ProblemDetails
        //        {
        //            Detail = ex.Message
        //        });
        //    } 
        //}
        //[HttpPost]
        //public async Task<IActionResult> AdicionarComentario(ValidacaoDesembolsoRequest request)
        //{
        //    try
        //    {
        //        await _aplicacaoService.AdicionarComentario(request);

        //        return Ok("Registro  criado com sucesso!");
        //    }
        //    catch (Exception ex)
        //    {
        //        await _plataformaService.SaveAsync();

        //        return BadRequest(new ProblemDetails
        //        {
        //            Detail = ex.Message
        //        });
        //    }
        //}
        #endregion
    }
}
