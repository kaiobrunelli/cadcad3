﻿using AmortizacaoCaixa.Domain;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using PlataformaOperacional.Application.Service;
using PlataformaOperacional.Application.Service.Interface;
using PlataformaOperacionalAPI.Requisicoes;
using PlataformaOperacionalAPI.Requisicoes.Cobranca;
using System.Diagnostics;
using System.DirectoryServices.AccountManagement;
using System.Reflection;

namespace PlataformaOperacionalAPI.Controllers
{
	[ApiController]
	[Route("/api/[Action]")]
	[Authorize(Policy = "AutorizaFuncionalidade")]
	public class CobrancaController : ControllerBase
	{
		private readonly ICobrancaService _cobrancaService;
		private readonly IPlataformaOperacionalService _plataformaService;
		private readonly IHttpContextAccessor _httpContextAccessor;
		public CobrancaController(ICobrancaService cobrancaService, IPlataformaOperacionalService plataformaService, IHttpContextAccessor httpContextAccessor)
		{
			_cobrancaService = cobrancaService;
			_plataformaService = plataformaService;
			_httpContextAccessor = httpContextAccessor;
		}

		#region AmortizacaoCaixa

		#region Consultas
		[HttpGet]
		public async Task<IActionResult> ControleGeralAmortizacaoCaixa()
		{
			var trilha = _plataformaService
				.GerarTrilhaDeAuditoria(
			"Consultar",
					$"Consultar todas as movimentações da amortização caixa",
					"Solicitado",
					_httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
					);
			try
			{
				var contratos = await _cobrancaService.ControleGeralAmortizacaoCaixaAsync();
				trilha.Resposta = "ACATADO";
				await _plataformaService.SaveAsync();
				return Ok(contratos);
			}
			catch (Exception ex)
			{
				trilha.Resposta = $"ERRO : {ex.Message}";
				await _plataformaService.SaveAsync();
				return BadRequest(new ProblemDetails { Detail = ex.Message });
			}

		}
		[HttpGet]
		public async Task<IActionResult> ConsultaControlesPendentes()
		{
			var trilha = _plataformaService
				.GerarTrilhaDeAuditoria(
			"Consultar",
					$"Consultar controles pendentes da amortização caixa",
					"Solicitado",
					_httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
					);
			try
			{
				var contratos = _cobrancaService.ConsultaControlesPendentes();
				trilha.Resposta = "ACATADO";
				await _plataformaService.SaveAsync();
				return Ok(contratos);
			}
			catch (Exception ex)
			{
				trilha.Resposta = $"ERRO : {ex.Message}";
				await _plataformaService.SaveAsync();
				return BadRequest(new ProblemDetails { Detail = ex.Message });
			}

		}
		[HttpGet]
		public async Task<IActionResult> ConsultarMovimentacoesParaAnalise(int coControle)
		{
			var trilha = _plataformaService
				.GerarTrilhaDeAuditoria(
			"Consultar",
					$"Consultar movimentações para análise da amortização caixa",
					"Solicitado",
					_httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
					);
			try
			{
				var contratos = _cobrancaService.ConsultarMovimentacoesParaAnalise(coControle);
				trilha.Resposta = "ACATADO";
				await _plataformaService.SaveAsync();
				return Ok(contratos);
			}
			catch (Exception ex)
			{
				trilha.Resposta = $"ERRO : {ex.Message}";
				await _plataformaService.SaveAsync();
				return BadRequest(new ProblemDetails { Detail = ex.Message });
			}

		}
		[HttpGet]
		public async Task<IActionResult> ConsultaDrpsDoControle(int coControle)
		{
			var trilha = _plataformaService
				.GerarTrilhaDeAuditoria(
			"Consultar",
					$"Consultar movimentações para análise da amortização caixa",
					"Solicitado",
					_httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
					);
			try
			{
				var contratos = _cobrancaService.ConsultaDrpsDoControle(coControle);
				trilha.Resposta = "ACATADO";
				await _plataformaService.SaveAsync();
				return Ok(contratos);
			}
			catch (Exception ex)
			{
				trilha.Resposta = $"ERRO : {ex.Message}";
				await _plataformaService.SaveAsync();
				return BadRequest(new ProblemDetails { Detail = ex.Message });
			}

		}
		[HttpGet]
		public async Task<IActionResult> ConsultarTodasMovimentacoesDoControle(int coControle)
		{
			var trilha = _plataformaService
				.GerarTrilhaDeAuditoria(
			"Consultar",
					$"Consultar movimentações para análise da amortização caixa",
					"Solicitado",
					_httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
					);
			try
			{
				var contratos = _cobrancaService.ConsultarTodasMovimentacoesDoControle(coControle);
				trilha.Resposta = "ACATADO";
				await _plataformaService.SaveAsync();
				return Ok(contratos);
			}
			catch (Exception ex)
			{
				trilha.Resposta = $"ERRO : {ex.Message}";
				await _plataformaService.SaveAsync();
				return BadRequest(new ProblemDetails { Detail = ex.Message });
			}

		}
		[HttpGet]
		public async Task<IActionResult> ConsultarMovimentacoesDeAmortizacao(int coControle)
		{
			var trilha = _plataformaService
				.GerarTrilhaDeAuditoria(
			"Consultar",
					$"Consultar movimentações para análise da amortização caixa",
					"Solicitado",
					_httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
					);
			try
			{
				var contratos = _cobrancaService.ConsultarMovimentacoesDeAmortizacao(coControle);
				trilha.Resposta = "ACATADO";
				await _plataformaService.SaveAsync();
				return Ok(contratos);
			}
			catch (Exception ex)
			{
				trilha.Resposta = $"ERRO : {ex.Message}";
				await _plataformaService.SaveAsync();
				return BadRequest(new ProblemDetails { Detail = ex.Message });
			}

		}
		[HttpGet]
		public async Task<IActionResult> ConsultarMovimentacoesDeDevolucao(int coControle)
		{
			var trilha = _plataformaService
				.GerarTrilhaDeAuditoria(
			"Consultar",
					$"Consultar movimentações para análise da amortização caixa",
					"Solicitado",
					_httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
					);
			try
			{
				var contratos = _cobrancaService.ConsultarMovimentacoesDeDevolucao(coControle);
				trilha.Resposta = "ACATADO";
				await _plataformaService.SaveAsync();
				return Ok(contratos);
			}
			catch (Exception ex)
			{
				trilha.Resposta = $"ERRO : {ex.Message}";
				await _plataformaService.SaveAsync();
				return BadRequest(new ProblemDetails { Detail = ex.Message });
			}

		}
		[HttpGet]
		public async Task<IActionResult> ConsultarMovimentacoesDeCci(int coControle)
		{
			var trilha = _plataformaService
				.GerarTrilhaDeAuditoria(
			"Consultar",
					$"Consultar movimentações para análise da amortização caixa",
					"Solicitado",
					_httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
					);
			try
			{
				var contratos = _cobrancaService.ConsultarMovimentacoesDeCci(coControle);
				trilha.Resposta = "ACATADO";
				await _plataformaService.SaveAsync();
				return Ok(contratos);
			}
			catch (Exception ex)
			{
				trilha.Resposta = $"ERRO : {ex.Message}";
				await _plataformaService.SaveAsync();
				return BadRequest(new ProblemDetails { Detail = ex.Message });
			}

		}

		#endregion

		#region Execução

		[HttpPost]
		public async Task<IActionResult> ProcessarAmortizacaoCaixa([FromBody] PedidoAutomacaoDto solicitacao)
		{
			var trilha = _plataformaService
				.GerarTrilhaDeAuditoria(
			"Consultar",
					$"Processar movimentações da amortização caixa do dia : {DateOnly.FromDateTime(DateTime.Now)}",
					"Solicitado",
					_httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
					);

			var pedido = _plataformaService
				.GerarPedidoDeAutomacao(this.GetType().Name.Replace("Service", ""), IdentificaEndpoint(), solicitacao.Senha,false);

			try
			{
				_ = Task.Run(() => _cobrancaService.ProcessarAmortizacaoCaixa(pedido));
				//_cobrancaService.ProcessarAmortizacaoCaixa(pedido);
				trilha.Resposta = "ACATADO";
				await _plataformaService.SaveAsync();
				return Accepted("ProcessarAmortizacaoCaixa");
			}
			catch (Exception ex)
			{
				trilha.Resposta = $"ERRO : {ex.Message}";
				await _plataformaService.SaveAsync();
				return BadRequest(new ProblemDetails { Detail = ex.Message });
			}

		}
		[HttpPost]
		public async Task<IActionResult> CancelarOperacaoAmortizacaoCaixa([FromBody] PedidoAutomacaoDto solicitacao)
		{
			var trilha = _plataformaService
				.GerarTrilhaDeAuditoria(
			"Cancelar",
					$"Cancelar movimentações da amortização",
					"Solicitado",
					_httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
					);

			var pedido = _plataformaService
				.GerarPedidoDeAutomacao(this.GetType().Name.Replace("Service", ""), IdentificaEndpoint(), solicitacao.Senha, solicitacao.MyExtra);

			try
			{
				_ = Task.Run(() => _cobrancaService.CancelarOperacaoAmortizacaoCaixa(pedido));
				trilha.Resposta = "ACATADO";
				await _plataformaService.SaveAsync();
				return Accepted(IdentificaEndpoint());
			}
			catch (Exception ex)
			{
				trilha.Resposta = $"ERRO : {ex.Message}";
				await _plataformaService.SaveAsync();
				return BadRequest(new ProblemDetails { Detail = ex.Message });
			}

		}
		#endregion

		#region Alterar Movimentações Financeiras
		[HttpPost]
		public async Task<IActionResult> ResetarMovimentacaoFinanceira(AlteracaoMovimentacaoFinanceira request)
		{
			var trilha = _plataformaService
				.GerarTrilhaDeAuditoria(
			"Consultar",
					$"Resetar movimentação da amortização caixa",
					"Solicitado",
					_httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
					);
			try
			{
				_cobrancaService.ResetarMovimentacaoFinanceira(request.CoMovimentacaoFinanceira, request.AcaoUsuario);
				trilha.Resposta = "ACATADO";
				await _plataformaService.SaveAsync();
				return Ok();
			}
			catch (Exception ex)
			{
				trilha.Resposta = $"ERRO : {ex.Message}";
				await _plataformaService.SaveAsync();
				return BadRequest(new ProblemDetails { Detail = ex.Message });
			}

		}
		[HttpPost]
		public async Task<IActionResult> LancarMovimentacaoFinanceiraTotalEmCci(AlteracaoMovimentacaoFinanceira request)
		{
			var trilha = _plataformaService
				.GerarTrilhaDeAuditoria(
			"Consultar",
					$"Lançar valor total da movimentação no CCI do processo da amortização caixa",
					"Solicitado",
					_httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
					);
			try
			{
				_cobrancaService.LancarMovimentacaoFinanceiraTotalEmCci(request.CoMovimentacaoFinanceira, request.AcaoUsuario);
				trilha.Resposta = "ACATADO";
				await _plataformaService.SaveAsync();
				return Ok();
			}
			catch (Exception ex)
			{
				trilha.Resposta = $"ERRO : {ex.Message}";
				await _plataformaService.SaveAsync();
				return BadRequest(new ProblemDetails { Detail = ex.Message });
			}

		}
		[HttpPost]
		public async Task<IActionResult> LancarMovimentacaoFinanceiraParcialCci(AlteracaoMovimentacaoFinanceira request)
		{
			var trilha = _plataformaService
				.GerarTrilhaDeAuditoria(
			"Consultar",
					$"Lançar valor total da movimentação no CCI do processo da amortização caixa",
					"Solicitado",
					_httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
					);
			try
			{
				_cobrancaService
					.LancarMovimentacaoFinanceiraParcialCci(request.CoMovimentacaoFinanceira, request.AcaoUsuario,request.TiposDeOperacao);
				trilha.Resposta = "ACATADO";
				await _plataformaService.SaveAsync();
				return Ok();
			}
			catch (Exception ex)
			{
				trilha.Resposta = $"ERRO : {ex.Message}";
				await _plataformaService.SaveAsync();
				return BadRequest(new ProblemDetails { Detail = ex.Message });
			}

		}


		#endregion

		#region Configurações
		[HttpGet]
		public async Task<IActionResult> ConsultarConfiguracoesGerais()
		{
			var trilha = _plataformaService
				.GerarTrilhaDeAuditoria(
			"Consultar",
					$"Consultar configurações da automação da amortização caixa",
					"Solicitado",
					_httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
					);
			try
			{
				var contratos = _cobrancaService.ConsultarConfiguracoesGerais();
				trilha.Resposta = "ACATADO";
				await _plataformaService.SaveAsync();
				return Ok(contratos);
			}
			catch (Exception ex)
			{
				trilha.Resposta = $"ERRO : {ex.Message}";
				await _plataformaService.SaveAsync();
				return BadRequest(new ProblemDetails { Detail = ex.Message });
			}

		}
		[HttpGet]
		public async Task<IActionResult> ConsultarHistoricoDeTms()
		{
			var trilha = _plataformaService
				.GerarTrilhaDeAuditoria(
			"Consultar",
					$"Consultar modelos de historico dos TMs da amortização caixa",
					"Solicitado",
					_httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
					);
			try
			{
				var resposta = _cobrancaService.ConsultarHistoricoDeTms();
				trilha.Resposta = "ACATADO";
				await _plataformaService.SaveAsync();
				return Ok(resposta);
			}
			catch (Exception ex)
			{
				trilha.Resposta = $"ERRO : {ex.Message}";
				await _plataformaService.SaveAsync();
				return BadRequest(new ProblemDetails { Detail = ex.Message });
			}

		}
		[HttpPost]
		public async Task<IActionResult> AlterarContratoCci(Contrato contrato)
		{
			var trilha = _plataformaService
				.GerarTrilhaDeAuditoria(
			"Consultar",
					$"Configurar contrato de CCI da amortização caixa",
					"Solicitado",
					_httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
					);
			try
			{
				_cobrancaService.AlterarContratoCci(contrato.NuContrato, contrato.NuContratoDv);
				trilha.Resposta = "ACATADO";
				await _plataformaService.SaveAsync();
				return Ok();
			}
			catch (Exception ex)
			{
				trilha.Resposta = $"ERRO : {ex.Message}";
				await _plataformaService.SaveAsync();
				return BadRequest(new ProblemDetails { Detail = ex.Message });
			}

		}
		[HttpPost]
		public async Task<IActionResult> AlterarHistoricoTms(ModeloHistoricoMovimentacao historico)
		{
			var trilha = _plataformaService
				.GerarTrilhaDeAuditoria(
			"Consultar",
					$"Configurar histórico de movimentação de TM da amortização caixa",
					"Solicitado",
					_httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
					);
			try
			{
				_cobrancaService.AlterarHistoricoTms(historico.IdModelo,historico.Historico);
				trilha.Resposta = "ACATADO";
				await _plataformaService.SaveAsync();
				return Ok();
			}
			catch (Exception ex)
			{
				trilha.Resposta = $"ERRO : {ex.Message}";
				await _plataformaService.SaveAsync();
				return BadRequest(new ProblemDetails { Detail = ex.Message });
			}

		}
		[HttpPost]
		public async Task<IActionResult> AlterarUnidadeDeMovimento(UnidadeDeMovimento unidade)
		{
			var trilha = _plataformaService
				.GerarTrilhaDeAuditoria(
			"Consultar",
					$"Alterar unidade de movimento da automação da amortização caixa",
					"Solicitado",
					_httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
					);
			try
			{
				_cobrancaService.AlterarUnidadeDeMovimento(unidade.UnidadeMovimento,unidade.UnidadeMovimentoDv);
				trilha.Resposta = "ACATADO";
				await _plataformaService.SaveAsync();
				return Ok();
			}
			catch (Exception ex)
			{
				trilha.Resposta = $"ERRO : {ex.Message}";
				await _plataformaService.SaveAsync();
				return BadRequest(new ProblemDetails { Detail = ex.Message });
			}

		}


		#endregion

		#region Relatórios

		[HttpGet]
		public async Task<IActionResult> ConsultarControleGeral(DateTime data)
		{
			var trilha = _plataformaService
				.GerarTrilhaDeAuditoria(
			"Consultar",
					$"Consultar todas as movimentações da amortização caixa do dia {data.Date}",
					"Solicitado",
					_httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
					);
			try
			{
				var contratos = _cobrancaService.ConsultarControleGeral(data);
				trilha.Resposta = "ACATADO";
				await _plataformaService.SaveAsync();
				return Ok(contratos);
			}
			catch (Exception ex)
			{
				trilha.Resposta = $"ERRO : {ex.Message}";
				await _plataformaService.SaveAsync();
				return BadRequest(new ProblemDetails { Detail = ex.Message });
			}

		}
		[HttpPost]
		public async Task<IActionResult> DownloadArquivosAmortizacaoCaixa(DateTime data)
		{
			var trilha = _plataformaService
				.GerarTrilhaDeAuditoria(
			"Download",
					$"Download arquivos da Amortização Caixa.",
					"Solicitado",
					_httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
					);


			try
			{


				var arquivoZIP = await _cobrancaService.DownloadArquivosAmortizacaoCaixa(data);

				if (arquivoZIP is not null)
				{
					arquivoZIP.Position = 0;
				}
				else
				{
					throw new ArgumentNullException("Arquivo não encontrado.");
				}
				
				string nomeArquivo = $"{Path.GetFileName($"Amortização Caixa - {data.Day}.{data.Month}.{data.Year}")}.zip";

				trilha.Resposta = "ACATADO";
				await _plataformaService.SaveAsync();
				return File(arquivoZIP, "application/zip", fileDownloadName: nomeArquivo, enableRangeProcessing: true);
			}
			catch (Exception ex)
			{
				trilha.Resposta = $"ERRO : {ex.Message}";
				await _plataformaService.SaveAsync();
				return BadRequest(new ProblemDetails { Detail = ex.Message });
			}
		}
        #endregion

        #endregion

        #region Encontro de Contas
        #region Consultas
        [HttpGet]
        public async Task<IActionResult> ControleGeralEncontroDeContas()
        {
            var trilha = _plataformaService
                .GerarTrilhaDeAuditoria(
            "Consultar",
                    $"Consultar controle de execução do encontro de contas",
                    "Solicitado",
                    _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                    );
            try
            {
                var controle = await _cobrancaService.ControleGeralEncontroDeContasAsync();
                trilha.Resposta = "ACATADO";
                await _plataformaService.SaveAsync();
                return Ok(controle);
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }

        }
        #endregion
        #region Execução
        [HttpPost]
        public async Task<IActionResult> ProcessarEncontroDeContas([FromBody] PedidoAutomacaoDto solicitacao)
        {
            var trilha = _plataformaService
                .GerarTrilhaDeAuditoria(
            "Consultar",
                    $"Processar encontro de contas : {DateOnly.FromDateTime(DateTime.Now)}",
                    "Solicitado",
                    _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                    );

            var pedido = _plataformaService
                .GerarPedidoDeAutomacao(this.GetType().Name.Replace("Service", ""), IdentificaEndpoint(), solicitacao.Senha, false);

            try
            {
                _ = Task.Run(() => _cobrancaService.ProcessarEncontroDeContas(pedido));
                //_cobrancaService.ProcessarAmortizacaoCaixa(pedido);
                trilha.Resposta = "ACATADO";
                await _plataformaService.SaveAsync();
                return Accepted("ProcessarEncontroDeContas");
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }

        }
        [HttpPost]
        public async Task<IActionResult> CancelarEncontroDeContas([FromBody] PedidoAutomacaoDto solicitacao)
        {
            var trilha = _plataformaService
                .GerarTrilhaDeAuditoria(
            "Cancelar",
                    $"Cancelar encontro de contas",
                    "Solicitado",
                    _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                    );

            var pedido = _plataformaService
                .GerarPedidoDeAutomacao(this.GetType().Name.Replace("Service", ""), IdentificaEndpoint(), solicitacao.Senha, solicitacao.MyExtra);

            try
            {
                _ = Task.Run(() => _cobrancaService.CancelarEncontroDeContas(pedido));
                trilha.Resposta = "ACATADO";
                await _plataformaService.SaveAsync();
                return Accepted(IdentificaEndpoint());
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }

        }
        #endregion

        #endregion

        #region Teste
        [HttpPost]
		public async Task<IActionResult> TesteSignalR()
		{

			var trilha = _plataformaService
				.GerarTrilhaDeAuditoria(
			"Consultar",
					$"Testando o SignalR | dia : {DateOnly.FromDateTime(DateTime.Now)}",
					"Solicitado",
					_httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
					);
			try
			{
				_=Task.Run(()=>_cobrancaService.TesteSignalR());
				trilha.Resposta = "ACATADO";
				await _plataformaService.SaveAsync();
				return Accepted(IdentificaEndpoint());//Colocar nome da rota do SignalR
			}
			catch (Exception ex)
			{
				trilha.Resposta = $"ERRO : {ex.Message}";
				await _plataformaService.SaveAsync();
				return BadRequest(new ProblemDetails { Detail = ex.Message });
			}

		}

		private string IdentificaEndpoint()
		{
			var parametros = _httpContextAccessor.HttpContext.GetEndpoint().DisplayName;

			var index = parametros.LastIndexOf('.');

			var endpoint = parametros.Substring(index + 1);

			return endpoint.Substring(0, endpoint.IndexOf("(") - 1);
		}
		#endregion
	}
}
