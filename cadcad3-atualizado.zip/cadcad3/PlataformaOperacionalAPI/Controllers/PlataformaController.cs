﻿using Azure.Core;
using ConsultarUnidades.Application;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using MudBlazor;
using PlataformaOperacional.Application.Service;
using PlataformaOperacional.Application.Service.Interface;
using System.Reflection.Metadata.Ecma335;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text.RegularExpressions;
using static System.Net.WebRequestMethods;

namespace PlataformaOperacionalAPI.Controllers
{
    [ApiController]
    [Route("/api/[Action]")]
    public class PlataformaController : ControllerBase
    {
        private readonly IPlataformaOperacionalService _plataformaService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IConfiguration _configuration;

        private readonly ConsultarUnidadesService _consultarUnidade;
		public PlataformaController(IHttpContextAccessor httpContextAccessor, IPlataformaOperacionalService plataformaService, IConfiguration configuration, ConsultarUnidadesService consultarUnidade)
		{
			_httpContextAccessor = httpContextAccessor;
			_plataformaService = plataformaService;
			_configuration = configuration;
			_consultarUnidade = consultarUnidade;
		}
		[HttpGet]
        public async Task<IActionResult> ConsultaUsuario()
        {
            var trilha = _plataformaService
                .GerarTrilhaDeAuditoria(
            "Consultar",
                    $"Consultar dados de autenticação do usuário.",
                    "Solicitado",
                    _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                    );
            try
            {

                var response = _plataformaService.IdentificarUsuario();
                if (response is null){ throw new Exception("Usuário não encontrado."); }

                trilha.Resposta = "ACATADO";
                await _plataformaService.SaveAsync();
                return Ok(response);
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }

        }
        [HttpGet]
        public async Task<IActionResult> ConsultaConfiguracoesUsuario()
        {
            var trilha = _plataformaService
                .GerarTrilhaDeAuditoria(
            "Consultar",
                    $"Consultar dados de configuração do usuário.",
                    "Solicitado",
                    _httpContextAccessor.HttpContext!.GetEndpoint()!.DisplayName!
                    );
            try
            {

                var response = await _plataformaService.ConfiguracoesDoUsuario();
                if (response is null) { throw new Exception("Configuração de usuário não encontrado."); }

                trilha.Resposta = "ACATADO";
                await _plataformaService.SaveAsync();
                return Ok(response);
            }
            catch (Exception ex)
            {
                trilha.Resposta = $"ERRO : {ex.Message}";
                await _plataformaService.SaveAsync();
                return BadRequest(new ProblemDetails { Detail = ex.Message });
            }

        }


        [HttpGet]
        public IActionResult ConsultaChavePublica()
        {
            try
            {

                var chave = _configuration.GetSection("ChavePublica").Value;
                //var chave = "-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAwSmmMWGULhf7qvKz8NYJ85LtIl0xz+56QuVVfrQcZ/fbrYB+F7miC/0Y0lKjC5pUx/PKjasPC3RFgFKhM3wPc2o+hhAFzi8IUaNAhMgfoZw7ccqqR7sJBHbhMkhSfEkob0x2W2DP8FmYefzTHozkrYvgK8HW7RvesSiQMu908AQRpvEjb8AWAG7WbZ0Vd9Sm2/keMezpg2ssl4Ke7MrPJc1I0z37C6IGwhma4MDTGLxQM+Ccm17ZHxdO9QxlReorZPf1cbj+Zk//+J5CaOATvD5HjVtgzz+cKrHHpGTjH9ryEnz29sfYQxbsT9hFQ6wD54jXQirMPLBgtTQnT2B5lQIDAQAB\n-----END PUBLIC KEY-----";

                return Ok(new { Key = chave });
            }
            catch (Exception ex)
            {
                return Problem($"Falha ao abrir chave pública: {ex.Message}");
            }
        }

		[HttpGet]
		public IActionResult VerificaBancoEmUso()
		{
            var db = _configuration.GetSection("ConnectionStrings")["Connectstring:PlataformaOperacional"];


			

			// Expressão regular para capturar o texto após "catalog = " até o ";"
			var match = Regex.Match(db, @"catalog\s*=\s*(.*?);", RegexOptions.IgnoreCase);

			if (match.Success)
			{
				string value = match.Groups[1].Value;
                return Ok(value);
			}
			else
			{
				Console.WriteLine("Não foi possível encontrar o valor do catalog.");
			}



			return BadRequest("Não foi possivel localizar");
		}

		#region Testes
		[HttpGet]
		public IActionResult ConsultarUnidade(string unidade,bool myExtra)
		{
			return Ok(_consultarUnidade.ConsultarUnidade(unidade,myExtra));
		}

		[HttpGet]
		public IActionResult ConsultarArquivos()
		{
            var listaArquivos = new List<string>();
            string origem = "\\"+"\\df7436sr200\\virtual-df7175pr021";
			//string destino = configuracao.DestinoArquivo;

			var arquivos = Directory.GetFiles(origem);

			foreach (var arquivo in arquivos)
			{
                listaArquivos.Add(Path.GetFileName(arquivo));
				//var nomeArquivo = GerarNomeDrp(arquivo, numeroDrp);

				//if (nomeArquivo is not null)
				//{
				//	var destinoFinal = $"{destino}\\{dataProcessada.Day}.{dataProcessada.Month}.{dataProcessada.Year}";

				//	if (!Directory.Exists(destinoFinal))
				//	{
				//		Directory.CreateDirectory(destinoFinal);
				//	}


				//	MoverArquivo(arquivo, $"{destinoFinal}\\{nomeArquivo}");
				//	break;
				
			}
            return Ok(listaArquivos);

		}

        [HttpGet]
        public IActionResult TestarImpressoras()
        {
            var resultados = new List<string>();

            var impressoras = new List<string>();
            impressoras.Add("\\\\df7436sr200\\virtual-df7175pr021");
            impressoras.Add("\\\\CCTDCAPLNT0025\\Remota_DF7175PR293");
            impressoras.Add("\\\\CCTDCAPLNT0025\\Remota_DF7175PR294");
            impressoras.Add("\\\\CCTDCAPLNT0025\\Remota_DF7175PR104");
            impressoras.Add("\\\\CCTDCAPLNT0025\\Remota_DF7175PR295");
            impressoras.Add("\\\\df7436sr200\\virtual-df7175pr020");

            foreach (var impressora in impressoras)
            {
                var criar = "ERRO";
                var ler = "ERRO";
                var mover = "ERRO";
                var apagar = "ERRO";
                var erro = "";
                try
                {
                    
                    System.IO.File.WriteAllText($"{impressora}\\TestePlataforma.txt", "TESTE DE IMPRESSORA");
                    criar = "OK";

                    int last = impressora.LastIndexOf('\\');
                    int secondLast = impressora.LastIndexOf('\\', last - 1);

                    var arquivos = Directory.GetFiles(impressora,"TestePlataforma.*");
                    if (!arquivos.IsNullOrEmpty())
                    {
                        ler = "OK";
                    }

                    foreach (var arquivo in arquivos)
                    {
                        string[] linhas = System.IO.File.ReadAllLines(arquivo);
                        if (System.IO.File.Exists(arquivo))
                        {
                            System.IO.File.Move(arquivo, $"{impressora}\\TestePlataformaOK.txt");
                            mover = "OK";
                        }
                        
                    }
                    if (System.IO.File.Exists($"{impressora}\\TestePlataformaOK.txt"))
                    {
                        System.IO.File.Delete($"{impressora}\\TestePlataformaOK.txt");
                        if (!System.IO.File.Exists($"{impressora}\\TestePlataformaOK.txt"))
                        {
                            apagar = "OK";
                        }
                    }

                    resultados.Add(
                        $"{impressora} : CRIAR = {criar} LER = {ler} MOVER = {apagar} APAGAR = {apagar} ERRO = {erro}");
                }
                catch (Exception ex)
                {
                    erro += ex.Message + ";";
                    resultados.Add(
                        $"{impressora} : CRIAR = {criar} LER = {ler} MOVER = {apagar} APAGAR = {apagar} ERRO = {erro}");

                    continue;
                }
                

            }

            return Ok(resultados);
            


        }

        #endregion

        [HttpGet]
        public async Task<IActionResult> ObterTodasMatriculas()
        {
            var response = await _plataformaService.ObterTodasMatriculas();
            return Ok(response); 
        }
        [HttpGet]
        public async Task<IActionResult> ObterMatriculasPorCoordenacao(string codigoCoordenacao)
        {
            var response = await _plataformaService.ObterMatriculasPorCoordenacao(codigoCoordenacao);
            return Ok(response);
        }
    }
}
