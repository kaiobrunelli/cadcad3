﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using PlataformaOperacionalAPI.Autorizacao;
using RedeCaixaUtilitario.Application;
using RedeCaixaUtilitario.Application.Interface;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using Utilitarios.Service;
using Utilitarios.Service.Interface;
using ValidadorDeArquivosApi.Application.Configuration;
using ValidadorDeArquivosApi.Application.Services;
using ValidadorDeArquivosApi.Application.Services.Interfaces;
using ValidadorDeArquivosApi.Core.Servicos;

namespace PlataformaOperacionalAPI.Extensions
{
    public static class AppExtensions
    {
        public static void AddPreRequireds(this WebApplicationBuilder builder)
        {
            //PRÉ-REQUISITOS
            builder.Services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            builder.Services.AddScoped<IUsuarioService, UsuarioService>() ;
            builder.Services.AddScoped<SignalRService>();
            builder.Services.AddScoped<IProgressNotifier, SignalRProgressNotifier>();
        }
        public static void AddSecurity(this WebApplicationBuilder builder)
        {
            using (RSA rsa = RSA.Create())
            {
                var chavePrivada = rsa.ExportRSAPrivateKey();
                var chavePublica = rsa.ExportSubjectPublicKeyInfo();

                byte[] chaveProtegida = ProtectedData.Protect(chavePrivada, null, DataProtectionScope.LocalMachine);
                File.WriteAllBytes("data_temp.bin", chaveProtegida);

                string caminho = "appsettings.json";

                string json = File.ReadAllText(caminho);
                var config = JsonSerializer.Deserialize<Dictionary<string, object>>(json);

                if (!config.ContainsKey("ChavePublica"))
                    config["ChavePublica"] = new Dictionary<string, string>();

                config["ChavePublica"] = new string(PemEncoding.Write("PUBLIC KEY".AsSpan(), chavePublica));


                string novoJson = JsonSerializer.Serialize(config, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(caminho, novoJson);
            }
        }
        public static void AddValidadorDeArquivos(this WebApplicationBuilder builder)
        {
            //VALIDADOR DE ARQUIVOS

            builder.Services.AddScoped<ProcessadorDeArquivoService>();
            builder.Services.AddScoped<IProcessarValidacaoService, ProcessarValidacaoService>();

            builder.Services.Configure<ArmazenamentoRetificadosOptions>(
                builder.Configuration.GetSection("ArmazenamentoRetificados"));

            builder.Services.AddScoped<IProcessarRetificacaoService, ProcessarRetificacaoService>();
        }
        public static void AddConfigurationAuthentication(this WebApplicationBuilder builder)
        {
            var keyGenerator = new byte[32];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(keyGenerator);
            }
            var key = Encoding.ASCII.GetBytes(Convert.ToBase64String(keyGenerator));

            builder.Services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            })
            .AddJwtBearer(options =>
            {
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = new SymmetricSecurityKey(key),
                    ValidateIssuer = false,
                    ValidateAudience = false
                };
            });
        }
        public static void AddConfigurationAuthorization(this WebApplicationBuilder builder)
        {
            builder.Services.AddAuthorization(options =>
            {
                options.AddPolicy("AutorizaFuncionalidade", policy =>
                    policy.Requirements.Add(new AutorizaFuncionalidade()));
            });

            builder.Services.AddTransient<IAuthorizationHandler, AutorizacaoPorFuncionalidade>();
        }
        public static void AddConfigurationSwagger(this WebApplicationBuilder builder)
        {
            builder.Services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "Plataforma API", Version = "v1" });
                c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
                {
                    Description = "JWT Authorization header using the Bearer scheme. Example: \"Authorization: Bearer {token}\"",
                    Name = "Authorization",
                    In = ParameterLocation.Header,
                    Type = SecuritySchemeType.ApiKey,
                    Scheme = "Bearer"
                });
                c.AddSecurityRequirement(new OpenApiSecurityRequirement
            {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type = ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            },
            new string[] {}
        }
        });
            });
        }

        public static void AddConfigurationCors(this WebApplicationBuilder builder)
        {
            builder.Services.AddCors(options =>
            {
                options.AddPolicy("AllowAll",
                    policy =>
                    {
                        policy
                        .WithOrigins("https://localhost:7224", "http://localhost:5181", "https://www.ativo.fgts.caixa/"
                        , "https://www.ativo.fgts.caixa/PlataformaOperacional/")
                        .AllowAnyHeader()
                        .AllowAnyMethod()
                        .AllowCredentials();
                    });


            });
        }

        public static void AddLocalConfiguration(this WebApplicationBuilder builder)
        {

           var finalizar = false;
           bool myExtra = false;
           string? matriculaUsuario = "c151896";
           bool criptografia = false;

            //Console.WriteLine("Bem vindo a configuração da Plataforma Operacional :");

            //while (!finalizar)
            //{
            //    Console.Clear();
            //    Console.WriteLine("Configuração de usuário");
            //    Console.WriteLine("Digite a matrícula a ser usada (c000000):");
            //    matriculaUsuario = Console.ReadLine();

            //    if (matriculaUsuario.IsNullOrEmpty())
            //    {
            //        Console.WriteLine("Mátricula é obrigatória!");
            //        continue;
            //    }
            //    if (new Regex(@"^[cC]\d{6}$").IsMatch(matriculaUsuario))
            //    {
            //        Console.WriteLine("Matrícula aceita!");
            //        Console.ReadLine();
            //        finalizar = true;
            //    }
            //    else
            //    {
            //        Console.WriteLine("Matrícula fora do padrão");
            //    }

            //}
            //finalizar = false;
            //while (!finalizar)
            //{
            //    Console.Clear();
            //    Console.WriteLine($"Como deseja utilizar o Rede Caixa?");
            //    Console.WriteLine($"1 - MyExtra");
            //    Console.WriteLine($"2 - Emulador");
            //    int? comando = Convert.ToInt32(Console.ReadLine());
            //    switch (comando)
            //    {
            //        case 1:
            //            myExtra = true;
            //            finalizar = true;
            //            break;
            //        case 2:
            //            myExtra = false;
            //            finalizar = true;
            //            break;
            //        default:
            //            Console.WriteLine("Comando inválido!");
            //            Console.ReadLine();
            //            break;
            //    }
            //}
            //finalizar = false;
            //while (!finalizar)
            //{
            //    Console.Clear();
            //    Console.WriteLine($"Deseja ativar a criptografia");
            //    Console.WriteLine($"1 - Sim");
            //    Console.WriteLine($"2 - Não");
            //    int comando = Convert.ToInt32(Console.ReadLine());
            //    switch (comando)
            //    {
            //        case 1:
            //            criptografia = true;
            //            finalizar = true;
            //            break;
            //        case 2:
            //            criptografia = false;
            //            finalizar = true;
            //            break;
            //        default:
            //            Console.WriteLine("Comando inválido!");
            //            Console.ReadLine();
            //            break;
            //    }
            //}


            //CONFIGURANDO APP SETTINGS

            string caminho = "appsettings.json";
            string json = File.ReadAllText(caminho);
            var config = JsonSerializer.Deserialize<Dictionary<string, object>>(json);

            if (!config.ContainsKey("RedeCaixaMyExtra"))
                config["RedeCaixaMyExtra"] = new Dictionary<string, string>();

            config["RedeCaixaMyExtra"] = myExtra;

            if (!config.ContainsKey("Security"))
                config["Security"] = new Dictionary<string, string>();

            config["Security"] = criptografia;

            if (!String.IsNullOrEmpty(matriculaUsuario))
            {
                if (!config.ContainsKey("MatriculaUsuario"))
                    config["MatriculaUsuario"] = new Dictionary<string, string>();

                config["MatriculaUsuario"] = matriculaUsuario;
            }
            else
            {
                if (config.ContainsKey("MatriculaUsuario"))
                    config.Remove("MatriculaUsuario");
            }


            string novoJson = JsonSerializer.Serialize(config, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(caminho, novoJson);

            Console.WriteLine("Iniciando API configurada!");
            


        }
        public static void ClearLocalConfiguration(this WebApplicationBuilder builder)
        {
            string caminho = "appsettings.json";
            string json = File.ReadAllText(caminho);
            var config = JsonSerializer.Deserialize<Dictionary<string, object>>(json);

            if (config.ContainsKey("Security"))
                config.Remove("Security");
            if (config.ContainsKey("RedeCaixaMyExtra"))
                config.Remove("RedeCaixaMyExtra");
            if (config.ContainsKey("MatriculaUsuario"))
                config.Remove("MatriculaUsuario");
        }
    }
}
