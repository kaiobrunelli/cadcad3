﻿using AmortizacaoCaixa.Application;
using AmortizacaoCaixa.Application.Interface;
using ChecklistContratacao.Application;
using ChecklistContratacao.Application.Interface;
using ConsultaCrf.Application;
using ConsultaCrf.Application.Interface;
using ConsultarUnidades.Application;
using ControleAnaliseDesembolso.Application;
using ControleAnaliseDesembolso.Application.Interface;
using ControleAnaliseDesembolso.Infra.Datas.Context;
using ControleAnaliseDesembolso.Interface;
using Desembolsos.Application;
using Desembolsos.Application.Interface;
using Desembolsos.Infra.Context;
using EncontroDeContas.Application;
using EncontroDeContas.Application.Interface;
using EntradaDeDados.Application;
using EntradaDeDados.Application.Interface;
using EntradaDeDados.Infra.Data.Context;
using ManipuladorEsteiraDesembolso.Application;
using ManipuladorEsteiraDesembolso.Application.Interface;
using Microsoft.EntityFrameworkCore;
using PlataformaNotificacao.Application;
using PlataformaNotificacao.Application.Interface;
using PlataformaNotificacao.Infra.Context;
using PlataformaOperacional.Application.Service;
using PlataformaOperacional.Application.Service.Interface;
using PlataformaOperacional.Infra.Data.Context;
using PreditorDeDesembolso.Application;
using PreditorDeDesembolso.Application.Interface;
using RedeCaixaUtilitario.Application;
using RedeCaixaUtilitario.Application.Interface;
using SaldoResidual.Application;
using SaldoResidual.Application.Interface;
using Utilitarios.Service;

namespace PlataformaOperacionalAPI.Extensions
{
    public static class ModuloExtensions
    {
        private static string Chave { get; set; }
        private static string ChaveAtivo { get; set; }
        private static string ChaveEntradaDeDados { get; set; }
        private static string ChaveDepuracao { get; set; }
        private static string ChaveRH { get; set; }
     

        public static void AddModulos(this WebApplicationBuilder builder)
        {
            CarregarChaves(builder);
            AddContextModulos(builder);
            AddModuloService(builder);
        }
        private static void CarregarChaves(WebApplicationBuilder builder)
        {
            if (builder.Environment.IsDevelopment())
            {
                Chave = builder.Configuration.GetSection("Connectstring")["PlataformaOperacionalTeste"]!;
                ChaveAtivo = builder.Configuration.GetSection("Connectstring")["PlataformaOperacionalAtivoTeste"]!;
                ChaveEntradaDeDados = builder.Configuration.GetSection("Connectstring")["PlataformaOperacionalEntradaDados"]!;
                ChaveDepuracao = builder.Configuration.GetSection("Connectstring")["PlataformaOperacionalDepuracao"]!;
                //ChaveRH = builder.Configuration.GetSection("Connectstring")["PlataformaOperacionalRHLocal"]!;
                ChaveRH = builder.Configuration.GetSection("Connectstring")["PlataformaOperacionalRH"]!;

                builder.Services.AddDbContext<PlataformaOperacionalContext>
                    (opts => opts.UseSqlServer(Chave));
            }
            if (builder.Environment.IsProduction())
            {
                Chave = builder.Configuration.GetSection("ConnectionStrings")["Connectstring:PlataformaOperacional"]!;
                ChaveAtivo = builder.Configuration.GetSection("ConnectionStrings")["Connectstring:PlataformaOperacionalAtivo"]!;

                ChaveEntradaDeDados = builder.Configuration.GetSection("ConnectionStrings")["Connectstring:PlataformaOperacionalEntradaDados"]!;

                ChaveDepuracao = builder.Configuration.GetSection("ConnectionStrings")["Connectstring:PlataformaOperacionalDepuracao"]!;
                ChaveRH = builder.Configuration.GetSection("Connectstring")["Connectstring:PlataformaOperacionalRH"]!;

            }
        }
        private static void AddContextModulos(WebApplicationBuilder builder)
        {
            
            builder.Services.AddDbContext<PlataformaOperacionalContext>
                    (opts => opts.UseSqlServer(Chave));
            //DESEMBOLSOS

            builder.Services.AddDbContext<DesembolsosContext>(options =>
            {
                options.UseSqlServer(Chave);
            });

            builder.Services.AddDbContext<EsteiraDepuracaoDesembolsosContext>(options =>
            {
                options.UseSqlServer(ChaveDepuracao, sqlOptions =>
                {
                    sqlOptions.UseCompatibilityLevel(120);
                });
            });

            //ENTRADA DE DADOS SERVICE
            builder.Services.AddDbContext<EntradaDeDadosContext>(options =>
            {
                options.UseSqlServer(Chave);
            });
            builder.Services.AddDbContext<Ativo659Context>(options =>
            {
                options.UseSqlServer(ChaveAtivo, sqlOptions =>
                {
                    sqlOptions.UseCompatibilityLevel(120);
                });
            });
            builder.Services.AddDbContext<EntradaDados659Context>(options =>
            {
                options.UseSqlServer(ChaveEntradaDeDados, sqlOptions =>
                {
                    sqlOptions.UseCompatibilityLevel(120);
                });
            });

        }
        private static void AddModuloService(WebApplicationBuilder builder)
        {
            builder.Services.AddScoped<ISaldoResidualService>
                (provider => new SaldoResidualService(Chave));

            builder.Services.AddScoped<IPreditorDeDesembolsoService>
                (provider => new PreditorDeDesembolsoService(Chave));

            builder.Services.AddScoped<IChecklistContratacaoService>
                (provider => new ChecklistContratacaoService(Chave));

            builder.Services.AddScoped<IConsultaCrfService>
                (provider => new ConsultaCrfService(Chave));

            builder.Services.AddScoped<IManipuladorEsteiraDesembolsoService>
                (provider => new ManipuladorEsteiraDesembolsoService(Chave));



            builder.Services.AddScoped<IAmortizacaoCaixaService>(provider =>
            {
                var modulo = new AmortizacaoCaixaService(Chave, ChaveAtivo);
                var observer = provider.GetRequiredService<SignalRService>();
                modulo.OnProgressUpdate += (sender, e) => _ = observer.HandlerObserver(sender, e);
                return modulo;
            });
            builder.Services.AddScoped<IEncontroDeContasService>(provider =>
            {
                var modulo = new EncontroDeContasService(Chave);
                var observer = provider.GetRequiredService<SignalRService>();
                modulo.OnProgressUpdate += (sender, e) => _ = observer.HandlerObserver(sender, e);
                return modulo;
            });

   
            builder.Services.AddDbContext<ControleAnaliseDesembolsoContext>(options =>
            {
                options.UseSqlServer(ChaveRH);
            });
      
            // NotificacaoService     \/\/\/\/\/  KAIO Adicionado primeiro teste 01/07
            builder.Services.AddScoped<IControleAnaliseDesembolsoService, ControleAnaliseDesembolsoService>(); 
            builder.Services.AddScoped<IEmpregadoCADService, EmpregadoCADService>();
            builder.Services.AddScoped<IFichaPedidoDesembolsoService, FichaPedidoDesembolsoService>();
            builder.Services.AddScoped<IValidadorDesembolsoService, ValidadorDesembolsoService>();
            builder.Services.AddScoped<IValoresReferenciaContratoService, ValoresReferenciaContratoService>();  
            builder.Services.AddScoped<UtilitarioMapperServicecopy>();  

       

            builder.Services.AddScoped<PlataformaNotificacaoContext>
                    (opts => new PlataformaNotificacaoContext(ChaveRH));

            builder.Services.AddScoped<INotificacaoService>(provider =>
            {
                var db = provider.GetRequiredService<PlataformaNotificacaoContext>();
                var empregados = provider.GetRequiredService<IEmpregadoService>();
                var signalR = provider.GetRequiredService<SignalRService>();
                //var servico = new NotificacaoService(chaveRH,empregados);
                var servico = new NotificacaoService(ChaveRH, empregados);
                servico.OnNotificacao += (sender, e) => _ = signalR.HandlerObserver(sender, e);
                return servico;
            });
            // NotificacoaService /\/\/\/\/


            builder.Services.AddScoped<IDesembolsosService, DesembolsosService>();
            builder.Services.AddScoped<IEmpregadoService, EmpregadoService>();


            builder.Services.AddScoped<ISiapfServiceFactory, SiapfServiceFactory>();

            builder.Services.AddScoped<IEntradaDeDadosService, EntradaDeDadosService>();
            builder.Services.AddScoped<ConsultarUnidadesService>();

            //MAIN-SERVICES
            builder.Services.AddScoped<IPlataformaOperacionalService, PlataformaOperacionalService>();
            builder.Services.AddScoped<IAplicacaoService, AplicacaoService>();
            builder.Services.AddScoped<IContratacaoService, ContratacaoService>();
            builder.Services.AddScoped<ICobrancaService, CobrancaService>();
            builder.Services.AddScoped<IMonitoramentoService, MonitoramentoService>();



        }
    }
}
