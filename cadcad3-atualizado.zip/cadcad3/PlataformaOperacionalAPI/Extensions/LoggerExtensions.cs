﻿using PlataformaOperacionalAPI.Logging;
using RedeCaixaUtilitario.Domain.Exceptions;
using Serilog;
using Serilog.Events;

namespace PlataformaOperacionalAPI.Extensions
{
    public static class LoggerExtensions
    {
        public static void AddLoggerConfiguration(this WebApplicationBuilder builder)
        {
            var logCaminho = Path.Combine(builder.Environment.ContentRootPath, "logs");

            static bool HasException<T>(Exception? ex) where T : Exception
            {
                while (ex is not null)
                {
                    if (ex is T)
                        return true;

                    ex = ex.InnerException;
                }

                return false;
            }

            builder.Host.UseSerilog((context, services, configuration) =>
            {
                configuration
                    .MinimumLevel.Error()
                    .MinimumLevel.Override("Microsoft", LogEventLevel.Error)
                    .MinimumLevel.Override("System", LogEventLevel.Error)
                    .Enrich.FromLogContext()
                    .Enrich.With(new LogEventEnricher())
                    .WriteTo.Console(outputTemplate:
                        "[{Timestamp:HH:mm:ss} {Level:u3}] [{SourceContext}] [{ServiceName}] {Message:lj}{NewLine}{Exception}");

                configuration.WriteTo.Logger(config =>
                {
                    config.Filter.ByIncludingOnly(e =>
                        e.Properties.TryGetValue("IsApplicationService", out var value) &&
                        value is ScalarValue { Value: true } &&
                        !HasException<RedeCaixaException>(e.Exception));

                    config.WriteTo.Map(
                        keyPropertyName: "ServiceName",
                        defaultKey: "General",
                        configure: (serviceName, sinkConfiguration) =>
                        {
                            var pasta = Path.Combine(logCaminho, serviceName);
                            Directory.CreateDirectory(pasta);

                            sinkConfiguration.File(
                                path: Path.Combine(pasta, "log-.txt"),
                                rollingInterval: RollingInterval.Day,
                                shared: true
                            );
                        });
                });

                configuration.WriteTo.Logger(config =>
                {
                    config.Filter.ByIncludingOnly(e =>
                        e.Properties.TryGetValue("IsApplicationService", out var value) &&
                        value is ScalarValue { Value: true } &&
                        HasException<RedeCaixaException>(e.Exception));

                    config.WriteTo.Map(
                        keyPropertyName: "ServiceName",
                        defaultKey: "General",
                        configure: (serviceName, sinkConfiguration) =>
                        {
                            var pasta = Path.Combine(logCaminho, serviceName, "RedeCaixa");
                            Directory.CreateDirectory(pasta);

                            sinkConfiguration.File(
                                path: Path.Combine(pasta, "log-.txt"),
                                rollingInterval: RollingInterval.Day,
                                shared: true
                            );
                        });
                });
            });
        }
    }
}
