using ControleAnaliseDesembolso.Application.Interface;
using ControleAnaliseDesembolso.Domain.Entitys;
using PlataformaOperacionalAPI.Extensions;
using RedeCaixaUtilitario.Application;
using RedeCaixaUtilitario.Domain.Model;
using Serilog;
using System.Text;

// habilita o enconding 1252 n�o presente no Net 8. Utilizado pelo validador de arquivos.
Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);

Log.Logger = new LoggerConfiguration()
    .MinimumLevel.Error()
    .Enrich.FromLogContext()
    .WriteTo.Console()
    .WriteTo.File("logs/log.txt", rollingInterval: RollingInterval.Day)
    .CreateLogger();

var builder = WebApplication.CreateBuilder(args);

if (builder.Environment.IsDevelopment())
{
    builder.AddLocalConfiguration();
}
else
{
    builder.ClearLocalConfiguration();
}

builder.AddSecurity();
builder.AddConfigurationAuthorization();






builder.Services.AddHttpContextAccessor();
builder.Services.AddSignalR();

builder.AddPreRequireds();
builder.AddLoggerConfiguration();
builder.AddModulos();



builder.AddConfigurationAuthentication();
builder.Services.AddControllers();

builder.Services.AddEndpointsApiExplorer();
builder.AddConfigurationSwagger();

builder.AddConfigurationCors();
builder.AddValidadorDeArquivos();


var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseSwagger();
app.UseSwaggerUI();

app.UseCors("AllowAll");
app.UseHttpsRedirection();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.MapHub<ChatHub>("/chatHub");
app.MapHub<ProgressHub>("/progressHub");

app.Run();
