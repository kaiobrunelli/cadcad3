﻿using AmortizacaoCaixa.Application.Interface;
using AmortizacaoCaixa.Domain;
using AmortizacaoCaixa.Domain.Dto;
using ChecklistContratacao.Domain.Dto;
using EncontroDeContas.Application.Interface;
using EncontroDeContas.Domain;
using EncontroDeContas.Domain.Dto;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using PlataformaOperacional.Application.Service.Interface;
using PlataformaOperacional.Domain.Model;
using RedeCaixaUtilitario.Domain.Enum;
using RedeCaixaUtilitario.Domain.Model;
using RedeCaixaUtilitario.Domain.Model.Siapf;
using System.Diagnostics;
using Utilitarios.Model;
using Utilitarios.Service;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace PlataformaOperacional.Application.Service
{
	public class CobrancaService : ICobrancaService
	{
		private readonly IAmortizacaoCaixaService _amortizacaoCaixaService;
		private readonly IEncontroDeContasService _encontroDeContasSerice;
		private readonly IPlataformaOperacionalService _plataformaService;
		private UtilitarioMapperService _mapper = new UtilitarioMapperService();

        public CobrancaService(IPlataformaOperacionalService plataformaService, IAmortizacaoCaixaService amortizacaoCaixaSerice, IEncontroDeContasService encontroDeContasSerice)
        {
            _plataformaService = plataformaService;
            _amortizacaoCaixaService = amortizacaoCaixaSerice;
            _encontroDeContasSerice = encontroDeContasSerice;
        }

        #region AmortizacaoCaixa

        #region Consultas
        //CRIAR DTOS
        public async Task<ReadControleGeralViewDto> ControleGeralAmortizacaoCaixaAsync()
		{
			var usuario = _plataformaService.IdentificarUsuario();
			var controle = _mapper.Map<ReadControleGeralViewDto>(_amortizacaoCaixaService.ControleGeralAmortizacaoCaixa());

			controle.BotaoExecutar = await _plataformaService.VerificaFuncionalidadeAutorizadaAsync("ProcessarAmortizacaoCaixa");
			controle.BotaoCancelar = await _plataformaService.VerificaFuncionalidadeAutorizadaAsync("CancelarOperacaoAmortizacaoCaixa");

			if (controle.QtdAnalisar != 0) { controle.BotaoExecutar = false; }

			if(controle.ResponsavelEmitirDrp is not null && controle.DescBotaoExecutar.Contains("Baixar DRP"))
			{
				if (controle.ResponsavelEmitirDrp.Contains(usuario.Matricula))
				{
					controle.BotaoExecutar = false;
					controle.Alertas.Add(new AmortizacaoCaixa.Domain.ControleGeralAlerta()
					{
						Alerta = "Responsável pela baixa não pode ser o responsável pela emissão da DRP.",
						Severity = Severity.Info.ToString(),
					});
				}
			}

			if (controle.Situacao.Contains("Finalizado"))
			{
				controle.BotaoExecutar = false;
				controle.Alertas.Add(new AmortizacaoCaixa.Domain.ControleGeralAlerta()
				{
					Alerta = "Todos os processos já estão finalizados.",
					Severity = Severity.Warning.ToString(),
				});
			}

			if (controle.DescBotaoCancelar.IsNullOrEmpty()) { controle.BotaoCancelar = false; }
			controle.BotaoConfigurar = await _plataformaService.VerificaFuncionalidadeAutorizadaAsync("ConsultarConfiguracoesGerais");
			controle.LocationSignalR = "ProcessarAmortizacaoCaixa";

			return controle;
		}

		public ReadRelatorioControleGeralDto ConsultarControleGeral(DateTime data)
		{
			var controle = _mapper.Map<ReadRelatorioControleGeralDto>(_amortizacaoCaixaService.ConsultarControleGeral(data));

			return controle;
		}

		public List<ControlePendente> ConsultaControlesPendentes()
		{
			return _amortizacaoCaixaService.ConsultaControlesPendentes();
		}

		public List<ReadDrpDto> ConsultaDrpsDoControle(int coControle)
		{
			var drps = _mapper.Map<ReadDrpDto>(_amortizacaoCaixaService.ConsultaDrpsDoControle(coControle));

			return drps;
		}

		public List<ReadMovimentacaoFinanceiraAmortizacaoCaixaDto> ConsultarMovimentacoesDeAmortizacao(int coControle)
		{
			var mov = _mapper.Map<ReadMovimentacaoFinanceiraAmortizacaoCaixaDto>(_amortizacaoCaixaService.ConsultarMovimentacoesDeAmortizacao(coControle));
			return mov;
		}

		public List<ReadMovimentacaoFinanceiraAmortizacaoCaixaCciDto> ConsultarMovimentacoesDeCci(int coControle)
		{
			var mov = _mapper.Map<ReadMovimentacaoFinanceiraAmortizacaoCaixaCciDto>(_amortizacaoCaixaService.ConsultarMovimentacoesDeCci(coControle));
			return mov;
		}

		public List<ReadMovimentacaoFinanceiraAmortizacaoCaixaDto> ConsultarMovimentacoesDeDevolucao(int coControle)
		{
			var mov = _mapper.Map<ReadMovimentacaoFinanceiraAmortizacaoCaixaDto>(_amortizacaoCaixaService.ConsultarMovimentacoesDeDevolucao(coControle));
			return mov;
		}

		public List<ReadMovimentacaoFinanceiraAmortizacaoCaixaAnaliseDto> ConsultarMovimentacoesParaAnalise(int coControle)
		{
			var mov = _mapper.Map<ReadMovimentacaoFinanceiraAmortizacaoCaixaAnaliseDto>(_amortizacaoCaixaService.ConsultarMovimentacoesParaAnalise(coControle));
			return mov;
		}

		public List<ReadMovimentacaoFinanceiraAmortizacaoCaixaDto> ConsultarTodasMovimentacoesDoControle(int coControle)
		{
			var mov = _mapper.Map<ReadMovimentacaoFinanceiraAmortizacaoCaixaDto>(_amortizacaoCaixaService.ConsultarTodasMovimentacoesDoControle(coControle));
			return mov;
		}

		#endregion

		#region Execução

		public void ProcessarAmortizacaoCaixa(PedidoDeAutomacao pedido)
		{
			//var metodo = new StackTrace().GetFrame(3).GetMethod().Name;
			//var pedido = _plataformaService.GerarPedidoDeAutomacao(this.GetType().Name.Replace("Service", ""), metodo, senha);
			try
			{
				_amortizacaoCaixaService.ProcessarAmortizacaoCaixa(pedido);
		
			}
			catch (Exception ex)
			{
				pedido.Obs = ex.Message;
				throw;
			}


		}
		
		public void CancelarOperacaoAmortizacaoCaixa(PedidoDeAutomacao pedido)
		{
			//var metodo = new StackTrace().GetFrame(3).GetMethod().Name;
			//var pedido = _plataformaService.GerarPedidoDeAutomacao(this.GetType().Name.Replace("Service", ""), metodo, senha);
			try
			{
				_amortizacaoCaixaService.CancelarOperacaoAmortizacaoCaixa(pedido);

			}
			catch (Exception ex)
			{
				pedido.Obs = ex.Message;
				throw;
			}


		}
		#endregion

		#region Alterar Movimentações Financeiras
		public void ResetarMovimentacaoFinanceira(int coMovimentacao, string acaoUsuario)
		{
			var usuario = _plataformaService.IdentificarUsuario();

			_amortizacaoCaixaService.ResetarMovimentacaoFinanceira(coMovimentacao, acaoUsuario,usuario);
		}
		public void LancarMovimentacaoFinanceiraTotalEmCci(int coMovimentacao, string acaoUsuario)
		{
			var usuario = _plataformaService.IdentificarUsuario();

			_amortizacaoCaixaService.LancarMovimentacaoFinanceiraTotalEmCci(coMovimentacao,acaoUsuario,usuario);
		}
		public void LancarMovimentacaoFinanceiraParcialCci(int coMovimentacao, string acaoUsuario, ConjuntoTo tosParaCci)
		{
			var usuario = _plataformaService.IdentificarUsuario();
			_amortizacaoCaixaService.LancarMovimentacaoFinanceiraParcialCci(coMovimentacao,acaoUsuario,tosParaCci, usuario);
		}
		#endregion

		#region Configurações

		public ReadConfiguracaoAmortizacaoCaixaDto ConsultarConfiguracoesGerais()
		{
			var configuracoes = 
				_mapper.Map<ReadConfiguracaoAmortizacaoCaixaDto>(_amortizacaoCaixaService.ConsultarConfiguracoesGerais());

			return configuracoes;
		}
		public void AlterarContratoCci(string contrato, string contratoDv)
		{
			_amortizacaoCaixaService.AlterarContratoCci(contrato, contratoDv);
		}
		public List<ReadHistoricoMovimentacaoDto> ConsultarHistoricoDeTms()
		{
			var historico = 
				_mapper.Map<ReadHistoricoMovimentacaoDto>(_amortizacaoCaixaService.ConsultarHistoricoDeTms());

			return historico;
		}
		public void AlterarHistoricoTms(int idModelo, string novoHistorico)
		{
			_amortizacaoCaixaService.AlterarHistoricoTms(idModelo, novoHistorico);
		}
		public void AlterarUnidadeDeMovimento(string unidade, string unidadeDv)
		{
			_amortizacaoCaixaService.AlterarUnidadeDeMovimento(unidade, unidadeDv);
		}

		#endregion

		#region Utilitarios
		public Task<MemoryStream?> DownloadArquivosAmortizacaoCaixa(DateTime dataMovimento)
		{
			return _amortizacaoCaixaService.DownloadArquivos(dataMovimento);
		}

        #endregion

        #endregion

        #region EncontroDeContas

        public void ProcessarEncontroDeContas(PedidoDeAutomacao pedido)
        {
            try
            {
                _encontroDeContasSerice.ProcessarEncontroDeContas(pedido);

            }
            catch (Exception ex)
            {
                pedido.Obs = ex.Message;
                throw;
            }


        }
        public void CancelarEncontroDeContas(PedidoDeAutomacao pedido)
        {
            try
            {
				_encontroDeContasSerice.CancelarEncontroDeContas(pedido);

            }
            catch (Exception ex)
            {
                pedido.Obs = ex.Message;
                throw;
            }


        }

        public async Task<ReadEncontroDeContasControleGeralViewDto> ControleGeralEncontroDeContasAsync()
		{
			var controle = _encontroDeContasSerice.ControleGeralEncontroDeContas();
			


            if (controle is null)
			{
				var controleDto = new ReadEncontroDeContasControleGeralViewDto();

				controleDto.PainelControle.Botoes.DescExecutar = "INICIAR";
				controleDto.PainelControle.Botoes.Executar = 
					await _plataformaService.VerificaFuncionalidadeAutorizadaAsync("ProcessarEncontroDeContas");

				controleDto.PainelControle.Botoes.Cancelar =
					await _plataformaService.VerificaFuncionalidadeAutorizadaAsync("CancelarEncontroDeContas");

                controleDto.PainelControle.Botoes.Configurar =
                    await _plataformaService.VerificaFuncionalidadeAutorizadaAsync("ConfigurarEncontroDeContas");

                return controleDto;
            }
			else
			{
                var controleDto =
                _mapper.Map<ReadEncontroDeContasControleGeralViewDto>(controle);


                controleDto.PainelControle.Botoes.DescExecutar = controle.DescBotaoExecutar;
                controleDto.PainelControle.Botoes.Executar =
                    await _plataformaService.VerificaFuncionalidadeAutorizadaAsync("ProcessarEncontroDeContas");

				if (controle.DescBotaoExecutar.ToUpper().Contains("BAIXAR"))
				{
                    controleDto.PainelControle.Botoes.Executar = _encontroDeContasSerice
                                .PodeBaixarDrp(_plataformaService.IdentificarUsuario().Matricula, controle.CoControle);
                }

                controleDto.PainelControle.Botoes.DescCancelar = controle.DescBotaoCancelar;
                controleDto.PainelControle.Botoes.Cancelar =
                    await _plataformaService.VerificaFuncionalidadeAutorizadaAsync("CancelarEncontroDeContas");

                controleDto.PainelControle.Botoes.Configurar =
                    await _plataformaService.VerificaFuncionalidadeAutorizadaAsync("ConfigurarEncontroDeContas");

                return controleDto;
            }
            
            //controleDto.BotaoExecutar = await _plataformaService.VerificaFuncionalidadeAutorizadaAsync("ProcessarEncontroDeContas");
            //controleDto.BotaoCancelar = await _plataformaService.VerificaFuncionalidadeAutorizadaAsync("CancelarEncontroDeContas");
            //controleDto.BotaoConfigurar = await _plataformaService.VerificaFuncionalidadeAutorizadaAsync("ConfigurarEncontroDeContas");
            //controleDto.DescBotaoCancelar = controleDto.DescBotaoCancelar ?? "CANCELAR";

        }

        #endregion

        #region Testes

        public async Task<string> TesteSignalR()
		{
			return await _amortizacaoCaixaService.TesteSignalR();
		}

		#endregion

	}
}
