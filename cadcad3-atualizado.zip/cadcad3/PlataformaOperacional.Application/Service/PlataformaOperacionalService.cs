﻿using Azure.Core;
using Microsoft.Extensions.Configuration;
using PlataformaNotificacao.Application.Interface;
using PlataformaNotificacao.Infra.Context;
using PlataformaOperacional.Application.Service.Interface;
using PlataformaOperacional.Domain.Model;
using PlataformaOperacional.Infra.Data.Context;
using RedeCaixaUtilitario.Domain.Model;
using System.Buffers.Text;
using System.Configuration;
using System.Diagnostics.Eventing.Reader;
using System.Security.Cryptography;
using System.Text;
using Utilitarios.Model;
using Utilitarios.Service.Interface;

namespace PlataformaOperacional.Application.Service
{
    public class PlataformaOperacionalService : IPlataformaOperacionalService
    {
        private readonly PlataformaOperacionalContext _context;
        private readonly IUsuarioService _usuarioService;
        private readonly IConfiguration _config;
        private readonly IEmpregadoService _empregadoService;
        public PlataformaOperacionalService(PlataformaOperacionalContext context, IUsuarioService usuarioService, IConfiguration config,
            IEmpregadoService empregadoService)
        {
            _context = context;
            _usuarioService = usuarioService;
            _config = config;
            _empregadoService = empregadoService;
        }

        public async Task SaveAsync()
        {
            await _context.SaveChangesAsync();
        }
        public Usuario IdentificarUsuario()
        {
            var usuario = _usuarioService.ConsultarUsuario();
            if(usuario is null) { throw new Exception("Usuário não encontrado"); }
            return usuario;
        }

        public TrilhaDeAuditoriaPlataforma GerarTrilhaDeAuditoria(string evento,string descEvneto, string respsota, string Endpoint)
        {
            var usuario = _usuarioService.ConsultarUsuario();
            if (usuario is null) { throw new Exception("Usuário não encontrado"); }

            var trilha = new TrilhaDeAuditoriaPlataforma()
            {
                Usuario = usuario.Matricula,
                EnderecoLogicoSolicitante = usuario.EnderecoLogico.ToString(),
                DataSolicitacao = DateTime.Now,
                Evento = evento,
                DescEvento = descEvneto,
                Resposta =respsota,
                Endpoint = Endpoint

            };
            _context.Add(trilha);
            _context.SaveChanges();
            return trilha;
        }

        public PedidoDeAutomacao GerarPedidoDeAutomacao(string area,string servico,string? senha = null, bool myExtra = false)
        {
            try
            {
                bool.TryParse(_config["Security"],out bool security);
                bool.TryParse(_config["RedeCaixaMyExtra"], out bool myExtraConfig);
                var user = _config["MatriculaUsuario"];


                Usuario? usuario;
                var ambiente = _config["ENVIRONMENT"] ?? string.Empty;
                if (ambiente.ToUpper().Contains("DEVELOPMENT"))
                {
                    
                    if (security)
                    {
                        //usuario = _usuarioService.ConsultarUsuario(senha);
                        byte[] chaveProtegida = File.ReadAllBytes("data_temp.bin");
                        byte[] chaveDesprotegida = ProtectedData.Unprotect(chaveProtegida, null, DataProtectionScope.LocalMachine);
                        var chave = new string(PemEncoding.Write("RSA PRIVATE KEY".AsSpan(), chaveDesprotegida));

                        usuario = _usuarioService
                            .ConsultarUsuario(LogUser.LogUserSenha(senha, chave));
                    }
                    else
                    {
                        usuario = _usuarioService.ConsultarUsuario(senha);
                    }

                    
                }
                else
                {
                    byte[] chaveProtegida = File.ReadAllBytes("data_temp.bin");
                    byte[] chaveDesprotegida = ProtectedData.Unprotect(chaveProtegida, null, DataProtectionScope.LocalMachine);
                    var chave = new string(PemEncoding.Write("RSA PRIVATE KEY".AsSpan(), chaveDesprotegida));

                    usuario = _usuarioService
                        .ConsultarUsuario(LogUser.LogUserSenha(senha, chave));
                }
                

				var pedido = new PedidoDeAutomacao()
				{
					Servico = servico,
					Area = area,
					MatriculaSolicitante = usuario.Matricula,
					DtSolicitacao = DateTime.Now,
					Usuario = usuario,
					MyExtra = myExtraConfig

				};
				_context.Add(pedido);
				_context.SaveChanges();
				return pedido;
			}
            catch (Exception ex)
            {

                throw new Exception($"Falha na solicitação do pedido. Erro: {ex}");
            }
            

            
        }
        public string TestaChavePrivada()
        {
            byte[] chaveProtegida = File.ReadAllBytes("data_temp.bin");
            byte[] chaveDesprotegida = ProtectedData.Unprotect(chaveProtegida, null, DataProtectionScope.LocalMachine);
            var chave = new string(PemEncoding.Write("RSA PRIVATE KEY".AsSpan(), chaveDesprotegida));

            return chave;
        }
   
        public async Task<ConfiguracaoUsuario>? ConfiguracoesDoUsuario()
        {

            var autorizado = await _usuarioService.ConsultarPermissoesDoUsuarioAsync();
            if (autorizado is null) { return null; }

            var configurado = new ConfiguracaoUsuario()
            {
                Nome = autorizado.nomeCompleto,
                Matricula = autorizado.matricula,
                Unidade = autorizado.unidade.cgc
            };

            try
            {
                var aplicativos = new List<Aplicativo>();
                var funcionalidades = autorizado.funcionalidades.Where(f => !f.nome.Contains("Gestor") && !f.nome.Contains("Operador")).ToList();

                foreach (var funcionalidade in funcionalidades)
                {
                    var aplicativo = _context.Aplicativos
                        .FirstOrDefault(a => a.NomeCentralPermissoes.ToUpper() == funcionalidade.nome.ToUpper() && a.Ativo == true);
                    //if (aplicativo is null) { throw new Exception("Aplicativo não foi encontrado."); }
                    if (aplicativo is not null)
                    {
						aplicativos.Add(aplicativo);
					}
                    
                }

                foreach (var idArea in aplicativos.Select(a => a.IdArea).Distinct())
                {
                    var area = _context.Areas.FirstOrDefault(a => a.Id == idArea);
                    if (area is null) { throw new Exception("Area não pode ser nula"); }
                    configurado.Areas.Add(area);
                }


                 foreach (var area in configurado.Areas)
                {

                    var apps = aplicativos.Where(a => a.IdArea == area.Id).ToList();
                    area.Aplicativos.AddRange(apps);
                }

                return configurado;
            }
            catch (Exception ex)
            {
                throw new Exception($"Falha ao carregar as configurações do usuário : {ex.Message}");
            }
        }
        public string ConsultarNomeUsuario(string matricula)
        {
            return _usuarioService.ConsultarNomeUsuario(matricula);
        }
       

        public async Task<bool> VerificaFuncionalidadeAutorizadaAsync(string rota)
        {
            return await _usuarioService.VerificaFuncionalidadeAutorizadaAsync(rota);
        }

        public async Task<List<string>> ObterTodasMatriculas() =>
            await _empregadoService.ObterTodasMatriculas();
        public async Task<List<string>> ObterMatriculasPorCoordenacao(string codigoCoordenacao) =>
            await _empregadoService.ObterMatriculasPorCoordenacao(codigoCoordenacao);

        private class LogUser : IDisposable
        {
            public static string LogUserSenha(string senhaFrontEnd, string chavePrivada)
            {
                var encriptado = Convert.FromBase64String(senhaFrontEnd);
                using RSA rsa = RSA.Create();

                rsa.ImportFromPem(chavePrivada);
               

                var descriptado = rsa.Decrypt(encriptado, RSAEncryptionPadding.OaepSHA256);
                var decryptedText = Encoding.UTF8.GetString(descriptado);

                return decryptedText;
            }

            public void Dispose()
            {         
                GC.SuppressFinalize(this);
            }

        }
    }




}
