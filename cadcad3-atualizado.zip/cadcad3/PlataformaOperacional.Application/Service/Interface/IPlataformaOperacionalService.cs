﻿using PlataformaOperacional.Domain.Model;
using RedeCaixaUtilitario.Domain.Model;
using Utilitarios.Model;

namespace PlataformaOperacional.Application.Service.Interface
{
    public interface IPlataformaOperacionalService
    {
        public Usuario IdentificarUsuario();
        public TrilhaDeAuditoriaPlataforma GerarTrilhaDeAuditoria(string evento, string DescEvneto, string resposta,string Endpoint);
        Task<ConfiguracaoUsuario>? ConfiguracoesDoUsuario();
        public PedidoDeAutomacao GerarPedidoDeAutomacao(string area,string servico, string? senha = null,bool myExtra=false);
        Task<bool> VerificaFuncionalidadeAutorizadaAsync(string rota);
        string ConsultarNomeUsuario(string matricula);

		Task SaveAsync();

        public string TestaChavePrivada();

        Task<List<string>> ObterTodasMatriculas();
        Task<List<string>> ObterMatriculasPorCoordenacao(string codigoCoordenacao);

    }
}
