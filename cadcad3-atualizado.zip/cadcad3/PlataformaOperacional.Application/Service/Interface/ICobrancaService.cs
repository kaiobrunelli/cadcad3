﻿using AmortizacaoCaixa.Domain;
using AmortizacaoCaixa.Domain.Dto;
using EncontroDeContas.Domain.Dto;
using RedeCaixaUtilitario.Domain.Model;
using RedeCaixaUtilitario.Domain.Model.Siapf;

namespace PlataformaOperacional.Application.Service.Interface
{
	public interface ICobrancaService
	{

		#region Amortização Caixa

		Task<ReadControleGeralViewDto> ControleGeralAmortizacaoCaixaAsync();

        ReadRelatorioControleGeralDto ConsultarControleGeral(DateTime data);
		List<ControlePendente> ConsultaControlesPendentes();
		List<ReadMovimentacaoFinanceiraAmortizacaoCaixaAnaliseDto> ConsultarMovimentacoesParaAnalise(int coControle);
		List<ReadDrpDto> ConsultaDrpsDoControle(int coControle);
		List<ReadMovimentacaoFinanceiraAmortizacaoCaixaDto> ConsultarTodasMovimentacoesDoControle(int coControle);
		List<ReadMovimentacaoFinanceiraAmortizacaoCaixaDto> ConsultarMovimentacoesDeAmortizacao(int coControle);
		List<ReadMovimentacaoFinanceiraAmortizacaoCaixaDto> ConsultarMovimentacoesDeDevolucao(int coControle);
		List<ReadMovimentacaoFinanceiraAmortizacaoCaixaCciDto> ConsultarMovimentacoesDeCci(int coControle);


		void ProcessarAmortizacaoCaixa(PedidoDeAutomacao pedido);
		void CancelarOperacaoAmortizacaoCaixa(PedidoDeAutomacao pedido);
		Task<string> TesteSignalR();
		Task<MemoryStream?> DownloadArquivosAmortizacaoCaixa(DateTime dataMovimento);
		#region Alterar Movimentações Financeiras
		void ResetarMovimentacaoFinanceira(int coMovimentacao, string acaoUsuario);
		void LancarMovimentacaoFinanceiraTotalEmCci(int coMovimentacao, string acaoUsuario);
		void LancarMovimentacaoFinanceiraParcialCci(int coMovimentacao, string acaoUsuario, ConjuntoTo tosParaCci);
		#endregion
		#region Configurações
		ReadConfiguracaoAmortizacaoCaixaDto ConsultarConfiguracoesGerais();
		void AlterarContratoCci(string contrato, string contratoDv);
		List<ReadHistoricoMovimentacaoDto> ConsultarHistoricoDeTms();
		void AlterarHistoricoTms(int idModelo, string novoHistorico);
		void AlterarUnidadeDeMovimento(string unidade, string unidadeDv);
		#endregion

		#endregion

		#region EncontroDeContas

		void ProcessarEncontroDeContas(PedidoDeAutomacao pedido);
		void CancelarEncontroDeContas(PedidoDeAutomacao pedido);

		Task<ReadEncontroDeContasControleGeralViewDto> ControleGeralEncontroDeContasAsync();
        #endregion
    }
}
