﻿using ChecklistContratacao.Domain.Dto;
using ChecklistContratacao.Domain.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios.Model;

namespace PlataformaOperacional.Application.Service.Interface
{
    public interface IContratacaoService
    {
        Task<ReadContratosChecklistDto?> ConsultarChecklist(string contrato);		
		Task<bool> CarregarChecklistContratosCarregados();
		Task<bool> AtualizarChecklist(RespostaChecklist resposta);
		Task<List<TipoRespostaChecklist>> ConsultarRespostasChecklist();
		Task<List<ReadContratosChecklistResumoDto>> ConsultaContratosParaConformidadeAsync();
		Task<List<Tomador>> ConsultarTomadores();
		Task<List<ResumoTomador>> ConsultarResumosTomador();
		Task<List<ResumoGeralChecklist>> ConsultarResumoGeralChecklist();
		Task<ResumoTomador> ConsultarResumoTomadorPorCoTomadorAsync(string CoTomador);
		Task<bool> CadastrarRessalvaAsync(CreateRessalvaChecklistDto ressalvaDto);
		Task<bool> AtualizarRessalvaAsync(RespostaRessalva ressalva);
		Task<List<ReadRessalvaChecklistDto>> ConsultarRessalvaPorContratoAsync(string contrato);
		Task DesativarRessalvaAsync(int idRessalva);
		Task<bool> FinalizaChecklistContrato(string coContrato);
		Task<bool> CancelarFinalizacaoChecklistContrato(string coContrato);
		Task<List<ResumoContratos>?> ConsultarResumoTodosContratos();
	}
}
