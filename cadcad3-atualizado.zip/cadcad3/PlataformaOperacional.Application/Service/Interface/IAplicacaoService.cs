﻿using ControleAnaliseDesembolso.Application.Dtos.Request;
using ControleAnaliseDesembolso.Application.Dtos.Response;
using Desembolsos.Domain;
using Desembolsos.Domain.Dto;
using ManipuladorEsteiraDesembolso.Domain.Model;
using Microsoft.AspNetCore.Http;
using PreditorDeDesembolso.Domain.Dto;
using RedeCaixaUtilitario.Domain.Model;
using SaldoResidual.Domain.Dto;
using Utilitarios.Model;
using ValidadorDeArquivosApi.Core.Dominios.ModelosDeArquivo;
using ValidadorDeArquivosApi.Core.Relatorio;

namespace PlataformaOperacional.Application.Service.Interface
{
    public interface IAplicacaoService
    {
        #region Saldo Residual
        Task RealizarOperacaoSaldoResidual(string senha);
        List<ReadOperacoesDiariasDto> LocalizarContratosParaAnalise();
        List<ReadOperacoesDiariasDto> LocalizarContratosNaoProcessados();
        List<ReadSituacaoOperacaoDto> LocalizarSituacaoOperacoes();
        void ProcessarContratoManual(string idContrato, string descTratamento);
        #endregion

        #region Esteira OAF
        List<DesembolsoOAF> ConsultarDesembolsoOAF(DateTime data);
        void ExpurgarDesembolsosOAF(string fid, string deObservacao);
        void ResetarDesembolsosOAF(string fid);

        #endregion

        #region Preditor de Desembolso
        ReadControlePreditorDeDesembolsoDto ConsultarDadosDoPreditorDeDesembolso();
		ReadPreditorAnaliticoPublicoDto ConsultarPreditorAnaliticoPublico();
		ReadPreditorAnaliticoPrivadoDto ConsultarPreditorAnaliticoPrivado();
		List<ReadRelatorioDeResultadosDTO> ConsultarRelatorioDeResultados();
		void AtualizarPreditorAnaliticoPrivado(ReadPreditorAnaliticoPrivadoDto dto);
		void AtualizarPreditorAnaliticoPublico(ReadPreditorAnaliticoPublicoDto dto);
		void ResetarPreditorAnaliticoPrivado();
		void ResetarPreditorAnaliticoPublico();
		void FinalizarPreditorEnviarEmail();
		List<ReadPreditorAutorizadosDto> ConsultarPreditorAutorizados();
		void CadastrarPreditorAutorizado(CreatePreditorAutorizadosDto cadastro);
		void DesabilitarPreditorAutorizado(string matricula);
        void CadastrarEventual(string matriculaEventual);
        void RemoverEventual(string matriculaEventual);
		List<ReadDestinatarioEmailPreditorDeDesembolsoDto> ConsultarEmailPreditor();
		void CadastrarEmailPreditor(CreateDestinatarioEmailPreditorDeDesembolsoDto destinatarioDto);
		void RemoverEmailPreditor(int coDestinatario);

		#endregion

        #region Desembolsos

        Task<ServiceResult> ProcessarDesembolsos(PedidoDeAutomacao pedido, CancellationToken ct);

        Task<ServiceResult> ProcessarDesembolsosBaixa(PedidoDeAutomacao pedido, List<int> controles, CancellationToken ct);

        Task<ServiceResult> CriarFluxoExecucao(List<DesembolsoFluxoDto> desembolsos);

        Task<ServiceResult> CancelarFluxoExecucao(int coFluxo);

        Task<List<DesembolsoDto>> ConsultarDesembolsosPendentes();

        Task<List<DrpDto>> ConsultarDrpsPendentes();

        Task<List<DrpDto>> ConsultarDrpsFinalizadas();

        Task<List<DrpDto>> ConsultarDrpsParaBaixa();

        Task<ConfiguracoesDesembolsosDto> ConsultarConfiguracoesCaixa();

        Task<ConfiguracoesDesembolsosDto> ConsultarConfiguracoesOutrosAfs();

        Task<List<ModeloHistoricoDto>> ConsultarHistoricos();

        Task<List<ControleExecucaoDto>> ConsultarControlesExecucao();
        Task<List<ControleExecucaoDto>> ConsultarControlesExecucaoPorMatricula();

        Task<UsuarioPerfilView> ConsultarPerfil();

        Task<List<ConsolidadoResumo>> ConsultarResumoConsolidado();

        Task<int> AtualizarContratosEsteira();

        Task<ServiceResult> TratarContratoManualmente(TratarDesembolso dadosTratar);

        #endregion

        #region ValidadorArquivo

        Task<RelatorioDeValidacao> ProcessarValidacaoAsync(IFormFile arquivo);

        #endregion

        #region Controle Analise Desembolso

        //Task<DesembolsoEntradaResponse> ConsultarDesembolso(int idFpd);

        //\/\/\/Metodos do FPD_SERVICE\/\/\/
        Task SalvarFpd(PedidoDesembolsoRequest Fpd);
        Task<PedidoConsultaContratoAfResponse> SolicitarDadosFPD(PedidoConsultaContratoAfRequest Pedido);
        //\/\/\Metodos do FPD_SERVICE/\/\/\

        Task<string?> ObterREsponsavelDesembolso(int coFpd);
        Task CriarFichaPedidoDesembolso(PedidoDesembolsoRequest request);
        Task ReenviarFichaPedidoDesembolso(int coFpd, PedidoDesembolsoRequest request);
        Task AdicionarComentario(ValidacaoDesembolsoRequest request);
        Task EditarComentario(EditarComentarioRequest request);
        Task RemoverComentario(int coRegistroValidacao, string matriculaSolicitante);
        Task ValidarDesembolso(int coDesembolso);
        Task ValidarTodosPendentes();
        Task<List<DesembolsoResponse>> ObterTodosDesembolsos();
        Task VincularResponsavel(int coDesembolso, string? matriculaResponsavel);
        Task<List<ValidacaoTemplateResponse>> ObterValidacoesTemplate();
        Task<List<ComentarioValidacaoResponse>> ObterComentarios(int coDesembolso);
        Task<DesembolsoDetalheResponse> ObterDetalheDesembolso(int coDesembolso);
        Task AprovarDesembolso(int coDesembolso, AprovarDesembolsoRequest request);
        Task BaixarDRP(int coDesembolso);
        Task RejeitarDesembolso(int coDesembolso, RejeitarDesembolsoRequest request);
        Task<List<RegistroDrpResponse>> ObterRegistrosDrp();
        Task BaixarDrpEmLote(BaixarDrpRequest request);


        //Task<DesembolsoEntradaResponse> ConsultarDesembolso(int idFpd);
        //Task<PedidoConsultaContratoAfResponse> SolicitarDadosFPD(PedidoConsultaContratoAfRequest Pedido);
        //Task SalvarFpd(PedidoDesembolsoRequest Fpd);



        //Task CriarFichaPedidoDesembolso(PedidoDesembolsoRequest request);

        //Task AdicionarComentario(ValidacaoDesembolsoRequest request);

        #endregion
    }
}
