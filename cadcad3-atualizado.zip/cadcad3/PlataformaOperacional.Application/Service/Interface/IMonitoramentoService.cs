﻿using ConsultaCrf.Domain.Dto;
using EntradaDeDados.Domain.Dto;
using RedeCaixaUtilitario.Domain.Model;
using Utilitarios.Model;

namespace PlataformaOperacional.Application.Service.Interface
{
	public interface IMonitoramentoService
	{
		#region Consulta CRF
		Task RealizarOperacaoCrf(PedidoDeAutomacao pedido);
		ReadConsultadoCrfDto ConsultarCrfAtual();
		ReadConsultadoCrfDto ConsultarCrfAnteriores(DateTime data);
		#endregion

		#region EntradaDeDados
		Task<ServiceResult> IncluirEntradaDados(List<EntradaDadosDto> entradaDados);

		Task<DateTime?> ConsultarUltimoControle();
        #endregion
    }
}
