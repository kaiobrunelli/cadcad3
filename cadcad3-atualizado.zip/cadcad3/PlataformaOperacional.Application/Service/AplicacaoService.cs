﻿using Azure.Core;
using ControleAnaliseDesembolso.Application.Dtos.Request;
using ControleAnaliseDesembolso.Application.Dtos.Response;
using ControleAnaliseDesembolso.Application.Interface;
using ControleAnaliseDesembolso.Domain.Entitys;
using ControleAnaliseDesembolso.Interface;
using Desembolsos.Application.Interface;
using Desembolsos.Domain;
using Desembolsos.Domain.Dto;
using ManipuladorEsteiraDesembolso.Application.Interface;
using ManipuladorEsteiraDesembolso.Domain.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using PlataformaOperacional.Application.Service.Interface;
using PreditorDeDesembolso.Application.Interface;
using PreditorDeDesembolso.Domain.Dto;
using RedeCaixaUtilitario.Domain.Model;
using SaldoResidual.Application.Interface;
using SaldoResidual.Domain.Dto;
using System.Diagnostics;
using Utilitarios.Model;
using Utilitarios.Service;
using Utilitarios.Service.Interface;
using ValidadorDeArquivosApi.Application.Services.Interfaces;
using ValidadorDeArquivosApi.Core.Dominios.ModelosDeArquivo;
using ValidadorDeArquivosApi.Core.Relatorio;

namespace PlataformaOperacional.Application.Service
{
	public class AplicacaoService : IAplicacaoService
	{
		private readonly ISaldoResidualService _saldoResidualService;
		private readonly IManipuladorEsteiraDesembolsoService _esteiraOAFService;
		private readonly IPlataformaOperacionalService _plataformaService;
		private readonly IPreditorDeDesembolsoService _preditorDeDesembolso;
		private readonly IControleAnaliseDesembolsoService _controleAnaliseDesembolso;
        private readonly IFichaPedidoDesembolsoService _fichaPedidoDesembolso;

        private readonly IUsuarioService _usuarioService;
		private readonly IDesembolsosService _desembolsosService;
		private readonly IProcessarValidacaoService _validadorService;
		private UtilitarioMapperService _mapper = new UtilitarioMapperService();
		//public AplicacaoService(ISaldoResidualService saldoResidualService, IPlataformaOperacionalService plataformaService, IManipuladorEsteiraDesembolsoService esteiraOAFService,
		//	IPreditorDeDesembolsoService preditorDeDesembolso, IUsuarioService usuarioService);
		public AplicacaoService(ISaldoResidualService saldoResidualService, IPlataformaOperacionalService plataformaService, IUsuarioService usuarioService,
			IManipuladorEsteiraDesembolsoService esteiraOAFService, IDesembolsosService desembolsosService, IPreditorDeDesembolsoService preditorDeDesembolso,
			IProcessarValidacaoService processarValidacaoService, IControleAnaliseDesembolsoService consultaAnaliseDesembolso, IFichaPedidoDesembolsoService fichaPedidoDesembolso)
		{
			_saldoResidualService = saldoResidualService;
			_plataformaService = plataformaService;
			_esteiraOAFService = esteiraOAFService;
			_preditorDeDesembolso = preditorDeDesembolso;
			_usuarioService = usuarioService;
			_desembolsosService = desembolsosService;
			_validadorService = processarValidacaoService;
			_controleAnaliseDesembolso = consultaAnaliseDesembolso;
			_fichaPedidoDesembolso = fichaPedidoDesembolso;

        }

		#region Saldo Residual
		public async Task RealizarOperacaoSaldoResidual(string senha)
		{
			var metodo = new StackTrace().GetFrame(3).GetMethod().Name;
			var pedido = _plataformaService.GerarPedidoDeAutomacao(this.GetType().Name.Replace("Service", ""), metodo, senha);
			try
			{
				_saldoResidualService.RealizarOperacaoSaldoResidual(pedido);
				await _plataformaService.SaveAsync();
			}
			catch (Exception ex)
			{
				pedido.Obs = ex.Message;
				await _plataformaService.SaveAsync();
				throw;
			}

		}

		public List<ReadOperacoesDiariasDto> LocalizarContratosParaAnalise()
		{
			var contratos = _saldoResidualService.LocalizarContratosParaAnalise();
			if (contratos.IsNullOrEmpty())
			{
				throw new Exception("Não foram encontrados contratos para análise.");
			}
			var contratosDto = _mapper.Map<ReadOperacoesDiariasDto>(contratos);
			return contratosDto;
		}

		public List<ReadOperacoesDiariasDto> LocalizarContratosNaoProcessados()
		{

			var contratos = _saldoResidualService.LocalizarContratosNaoProcessados();
			if (contratos is null)
			{
				throw new Exception("Contratos não podem ser nulos.");
			}
			var contratosDto = _mapper.Map<ReadOperacoesDiariasDto>(contratos);
			return contratosDto;
		}

		public List<ReadSituacaoOperacaoDto> LocalizarSituacaoOperacoes()
		{

			var contratos = _saldoResidualService.LocalizarSituacaoOperacoes();
			if (contratos.IsNullOrEmpty())
			{
				throw new Exception("Não foram encontrados operações.");
			}
			var operacoesDto = _mapper.Map<ReadSituacaoOperacaoDto>(contratos);
			return operacoesDto;
		}
		public void ProcessarContratoManual(string coOperacao, string descTratamento)
		{
			var usuario = _plataformaService.IdentificarUsuario();
			_saldoResidualService.ProcessarContratoManual(coOperacao, descTratamento, usuario);
		}

		#endregion

		#region Manipulador Esteira OAF
		public List<DesembolsoOAF> ConsultarDesembolsoOAF(DateTime data)
		{
			var contratos = _esteiraOAFService.ConsultarDesembolsosOAF(data);
			if (contratos.IsNullOrEmpty())
			{
				throw new Exception("Não foram encontrados registros.");
			}
			//var contratosDto = _mapper.Map<ReadOperacoesDiariasDto>(contratos);
			//return contratosDto;
			return contratos;
		}
		public void ExpurgarDesembolsosOAF(string fid, string deObservacao)
		{
			_esteiraOAFService.ExpurgarDesembolsosOAF(fid, deObservacao);
		}
		public void ResetarDesembolsosOAF(string fid)
		{
			_esteiraOAFService.ResetarDesembolsosOAF(fid);
		}
		#endregion

		#region Preditor de Desembolso
		public ReadControlePreditorDeDesembolsoDto ConsultarDadosDoPreditorDeDesembolso()
		{
			var usuario = _plataformaService.IdentificarUsuario();
			var preditor = _preditorDeDesembolso.ConsultarControlePreditorDeDesembolso(usuario);
			if (preditor is null)
			{
				throw new Exception("Não foi encontrada a predição atual.");
			}
			var preditorDto = _mapper.Map<ReadControlePreditorDeDesembolsoDto>(preditor);
			//preditorDto.AnaliticoSetorPrivado = _mapper.Map<ReadPreditorAnaliticoPrivadoDto>(preditor.AnaliticoSetorPrivado);
			if (preditor.AnaliticoSetorPrivado is not null)
			{
				preditorDto.AnaliticoSetorPrivado = new ReadPreditorAnaliticoPrivadoDto()
				{
					VrConsolidado = preditor.AnaliticoSetorPrivado.VrConsolidadoEfetivado ?? preditor.AnaliticoSetorPrivado.VrConsolidado,
					VrLegado = preditor.AnaliticoSetorPrivado.VrLegadoEfetivado ?? preditor.AnaliticoSetorPrivado.VrLegado,
					VrProCotista = preditor.AnaliticoSetorPrivado.VrProCotistaEfetivado ?? preditor.AnaliticoSetorPrivado.VrProCotista,
					VrCalculado = preditor.AnaliticoSetorPrivado.VrTotal,
					VrTotal = preditor.AnaliticoSetorPrivado.VrTotalEfetivado ?? preditor.AnaliticoSetorPrivado.VrTotal
				};
			}

			if (preditor.AnaliticoSetorPublico is not null)
			{
				preditorDto.AnaliticoSetorPublico = new ReadPreditorAnaliticoPublicoDto()
				{
					VrAFCaixa = preditor.AnaliticoSetorPublico.VrAFCaixaEfetivado ?? preditor.AnaliticoSetorPublico.VrAFCaixa,
					VrOutrosAF = preditor.AnaliticoSetorPublico.VrOutrosAFEfetivado ?? preditor.AnaliticoSetorPublico.VrOutrosAF,
					VrCalculado = preditor.AnaliticoSetorPublico.VrTotal,
					VrTotal = preditor.AnaliticoSetorPublico.VrTotalEfetivado ?? preditor.AnaliticoSetorPublico.VrTotal
				};
			}


			var autorizacao = _preditorDeDesembolso.ConsultaAutorizacoes(usuario);

			preditorDto.BtnPrivado = autorizacao.BtnPrivado;
			preditorDto.BtnPublico = autorizacao.BtnPublico;
			preditorDto.BtnConfigurar = autorizacao.BtnConfiguracao;
			preditorDto.BtnFinalizador = autorizacao.BtnFinalizar;

			//TESTE DE ALERTAS

			//preditorDto.Alertas.Add(new ControleGeralPreditorAlerta()
			//{
			//	Alerta = "Alertando sobre algo, só não sei oque...",
			//	Severity = Severity.Info.ToString()
			//});
			//preditorDto.Alertas.Add(new ControleGeralPreditorAlerta()
			//{
			//	Alerta = "Algo de errado Não está certo...",
			//	Severity = Severity.Warning.ToString()
			//});
			//preditorDto.Alertas.Add(new ControleGeralPreditorAlerta()
			//{
			//	Alerta = "DEU RUIM...",
			//	Severity = Severity.Error.ToString()
			//});



			return preditorDto;
		}
		public ReadPreditorAnaliticoPrivadoDto ConsultarPreditorAnaliticoPrivado()
		{
			var usuario = _plataformaService.IdentificarUsuario();
			var preditor = _preditorDeDesembolso.ConsultarPreditorAnaliticoPrivado(usuario);
			if (preditor is null)
			{
				throw new Exception("Não foi encontrada a predição atual do setor privado.");
			}
			var preditorDto = _mapper.Map<ReadPreditorAnaliticoPrivadoDto>(preditor);
			return preditorDto;
		}
		public ReadPreditorAnaliticoPublicoDto ConsultarPreditorAnaliticoPublico()
		{
			var usuario = _plataformaService.IdentificarUsuario();
			var preditor = _preditorDeDesembolso.ConsultarPreditorAnaliticoPublico(usuario);
			var preditorDto = _mapper.Map<ReadPreditorAnaliticoPublicoDto>(preditor);
			return preditorDto;
		}
		public List<ReadRelatorioDeResultadosDTO> ConsultarRelatorioDeResultados()
		{
			var usuario = _plataformaService.IdentificarUsuario();
			var preditor = _preditorDeDesembolso.ConsultarRelatorioDeResultados(usuario);
			var preditorDto = _mapper.Map<ReadRelatorioDeResultadosDTO>(preditor);
			return preditorDto;
		}

		public void AtualizarPreditorAnaliticoPrivado(ReadPreditorAnaliticoPrivadoDto dto)
		{
			var usuario = _plataformaService.IdentificarUsuario();
			var usuarioNT = _usuarioService.ConsultarUsuarioNt(usuario.Matricula);
			_preditorDeDesembolso.AtualizarPreditorAnaliticoPrivado(dto, usuario, usuarioNT);
		}
		public void AtualizarPreditorAnaliticoPublico(ReadPreditorAnaliticoPublicoDto dto)
		{
			var usuario = _plataformaService.IdentificarUsuario();
			var usuarioNT = _usuarioService.ConsultarUsuarioNt(usuario.Matricula);
			_preditorDeDesembolso.AtualizarPreditorAnaliticoPublico(dto, usuario, usuarioNT);
		}
		public void ResetarPreditorAnaliticoPublico()
		{
			var usuario = _plataformaService.IdentificarUsuario();
			_preditorDeDesembolso.ResetarPreditorAnaliticoPublico(usuario);
		}
		public void ResetarPreditorAnaliticoPrivado()
		{
			var usuario = _plataformaService.IdentificarUsuario();
			_preditorDeDesembolso.ResetarPreditorAnaliticoPrivado(usuario);
		}
		public void FinalizarPreditorEnviarEmail()
		{
			var usuario = _plataformaService.IdentificarUsuario();
			_preditorDeDesembolso.FinalizarPreditorEnviarEmail(usuario);
		}

		#region Autorizações Preditor
		public List<ReadPreditorAutorizadosDto> ConsultarPreditorAutorizados()
		{
			var preditorDto = _mapper.Map<ReadPreditorAutorizadosDto>(
				_preditorDeDesembolso.ConsultarPreditorAutorizados(_plataformaService.IdentificarUsuario()));

			return preditorDto;
		}
		public void CadastrarPreditorAutorizado(CreatePreditorAutorizadosDto cadastro)
		{
			var usuario = _plataformaService.IdentificarUsuario();
			cadastro.NomeOperador = _plataformaService.ConsultarNomeUsuario(cadastro.CoMatricula);
			_preditorDeDesembolso.CadastrarPreditorAutorizado(usuario, cadastro);
		}
		public void DesabilitarPreditorAutorizado(string matricula)
		{
			var usuario = _plataformaService.IdentificarUsuario();
			_preditorDeDesembolso.DesabilitarPreditorAutorizado(usuario, matricula);
		}
		public void CadastrarEventual(string matriculaEventual)
		{
			var usuario = _plataformaService.IdentificarUsuario();
			_preditorDeDesembolso.CadastrarEventual(usuario, matriculaEventual);
		}
		public void RemoverEventual(string matriculaEventual)
		{
			var usuario = _plataformaService.IdentificarUsuario();
			_preditorDeDesembolso.RemoverEventual(usuario, matriculaEventual);
		}
		public List<ReadDestinatarioEmailPreditorDeDesembolsoDto> ConsultarEmailPreditor()
		{
			var preditorDto = _mapper.Map<ReadDestinatarioEmailPreditorDeDesembolsoDto>(
				_preditorDeDesembolso.ConsultarEmailPreditor(_plataformaService.IdentificarUsuario()));

			return preditorDto;
		}
		public void CadastrarEmailPreditor(CreateDestinatarioEmailPreditorDeDesembolsoDto destinatarioDto)
		{
			var usuario = _plataformaService.IdentificarUsuario();
			_preditorDeDesembolso.CadastrarEmailPreditor(usuario, destinatarioDto);
		}
		public void RemoverEmailPreditor(int coDestinatario)
		{
			var usuario = _plataformaService.IdentificarUsuario();
			_preditorDeDesembolso.RemoverEmailPreditor(usuario, coDestinatario);
		}
        #endregion

        #endregion

        #region Desembolsos
    

        public async Task<ServiceResult> ProcessarDesembolsos(PedidoDeAutomacao pedido, CancellationToken ct) =>
			await _desembolsosService.ProcessarDesembolsos(pedido, ct);

        public async Task<ServiceResult> ProcessarDesembolsosBaixa(PedidoDeAutomacao pedido, List<int> controles, CancellationToken ct)
			=>await _desembolsosService.ProcessarDesembolsosBaixa(pedido, controles, ct);

		public async Task<ServiceResult> CriarFluxoExecucao(List<DesembolsoFluxoDto> desembolsos)
		{
			var usuario = _plataformaService.IdentificarUsuario();
			return await _desembolsosService.CriarFluxoExecucao(usuario, desembolsos);
		}

		public async Task<ServiceResult> CancelarFluxoExecucao(int coFluxo)
		{
			var usuario = _plataformaService.IdentificarUsuario();
			return await _desembolsosService.CancelarFluxoExecucao(usuario, coFluxo);
		}

		public async Task<ServiceResult> TratarContratoManualmente(TratarDesembolso dadosTratar)
		{
			var usuario = _plataformaService.IdentificarUsuario();
			return await _desembolsosService.TratarDesembolsoManualmente(dadosTratar, usuario);
		}

		public async Task<List<DesembolsoDto>> ConsultarDesembolsosPendentes()
		{
			var desembolsosPendentes = await _desembolsosService.ConsultarDesembolsosPendentes();
			return _mapper.Map<DesembolsoDto>(desembolsosPendentes);
		}

		public async Task<List<DrpDto>> ConsultarDrpsPendentes()
		{
			int[] statuPendentes = [0, 1, 3, 4];

			var drps = await _desembolsosService.ConsultarDrps();
			return _mapper.Map<DrpDto>(drps.Where(d => statuPendentes.Contains(d.IcStatus)));
		}

		public async Task<List<DrpDto>> ConsultarDrpsFinalizadas()
		{
			int[] statusFinalizadas = [2];

			var drps = await _desembolsosService.ConsultarDrps();

			return _mapper.Map<DrpDto>(drps
				.Where(d => statusFinalizadas.Contains(d.IcStatus))
				.OrderByDescending(d => d.IdDrp));
		}

		public async Task<List<DrpDto>> ConsultarDrpsParaBaixa()
		{
			int[] statusParaBaixa = [1, 4, 8];

			var drpsPendentes = await _desembolsosService.ConsultarDrps();
			return _mapper.Map<DrpDto>(drpsPendentes.Where(d => statusParaBaixa.Contains(d.IcStatus)));
		}

		public async Task<ConfiguracoesDesembolsosDto> ConsultarConfiguracoesCaixa()
		{
			var configuracoes = await _desembolsosService.ConsultarConfiguracoes();

			ConfiguracoesDesembolsos configuracaoCaixa = configuracoes
				.SingleOrDefault(c => c.DtExclusao == null && c.Tomador == "53000")
				?? throw new InvalidDataException("Configurações não encontradas.");

			return _mapper.Map<ConfiguracoesDesembolsosDto>(configuracaoCaixa);
		}

		public async Task<ConfiguracoesDesembolsosDto> ConsultarConfiguracoesOutrosAfs()
		{
			var configuracoes = await _desembolsosService.ConsultarConfiguracoes();

			ConfiguracoesDesembolsos configuracaoOutrosAfs = configuracoes
				.SingleOrDefault(c => c.DtExclusao == null && c.Tomador == null)
				?? throw new InvalidDataException("Configurações não encontradas.");

			return _mapper.Map<ConfiguracoesDesembolsosDto>(configuracaoOutrosAfs);
		}

		public async Task<List<ModeloHistoricoDto>> ConsultarHistoricos()
		{
			var historicos = await _desembolsosService.ConsultarHistoricos();
			return _mapper.Map<ModeloHistoricoDto>(historicos);
		}

		public async Task<List<ControleExecucaoDto>> ConsultarControlesExecucao()
		{
			var controles = await _desembolsosService.ConsultarControlesExecucao();
			return _mapper.Map<ControleExecucaoDto>(controles);
		}

        public async Task<List<ControleExecucaoDto>> ConsultarControlesExecucaoPorMatricula()
        {
            var usuario = _plataformaService.IdentificarUsuario();

            var controles = await _desembolsosService.ConsultarControlesExecucao();
			
			var controlesUsuario = controles
				.Where(c => c.MatriculaEmpregadoInicial!.Equals(usuario.Matricula, StringComparison.OrdinalIgnoreCase));

			return _mapper.Map<ControleExecucaoDto>(controlesUsuario);
		}

		public async Task<UsuarioPerfilView> ConsultarPerfil()
		{
			var usuario = _plataformaService.IdentificarUsuario();
			return await _desembolsosService.ConsultarPerfil(usuario.Matricula);
		}

		public async Task<List<ConsolidadoResumo>> ConsultarResumoConsolidado() => await _desembolsosService.ConsultarResumoConsolidado();

		public async Task<int> AtualizarContratosEsteira() => await _desembolsosService.AtualizarListaDesembolsosAsync();

		#endregion

		#region Validador Arquivo

        public async Task<RelatorioDeValidacao> ProcessarValidacaoAsync(IFormFile arquivo)
		{
			return await _validadorService.ProcessarValidacaoAsync(arquivo);
		}


        #endregion


        #region Consulta Analise Desembolso    
        //public async Task<DesembolsoEntradaResponse> ConsultarDesembolso(int idFpd)
        //          => await _consultaAnaliseDesembolso.ConsultarDesembolso(idFpd);

        //\/\/\/Metodos do FPD_SERVICE\/\/\/
        public async Task SalvarFpd(PedidoDesembolsoRequest Fpd)
			=> await _fichaPedidoDesembolso.SalvarFpd(Fpd);
        public async Task<PedidoConsultaContratoAfResponse> SolicitarDadosFPD(PedidoConsultaContratoAfRequest Pedido)
			=> await _fichaPedidoDesembolso.SolicitarDadosFPD(Pedido);
        //\/\/\Metodos do FPD_SERVICE/\/\/\

        public async Task<string?> ObterREsponsavelDesembolso(int coFpd) 
			=> await  _controleAnaliseDesembolso.ObterREsponsavelDesembolso(coFpd);
        public async Task CriarFichaPedidoDesembolso(PedidoDesembolsoRequest request)
			=> await _controleAnaliseDesembolso.CriarFichaPedidoDesembolso(request);
        public async Task ReenviarFichaPedidoDesembolso(int coFpd, PedidoDesembolsoRequest request)
            => await _controleAnaliseDesembolso.ReenviarFichaPedidoDesembolso(coFpd, request);
        public async Task AdicionarComentario(ValidacaoDesembolsoRequest request)
            => await _controleAnaliseDesembolso.AdicionarComentario(request);
        public async Task EditarComentario(EditarComentarioRequest request)
            => await _controleAnaliseDesembolso.EditarComentario(request);
        public async Task RemoverComentario(int coRegistroValidacao, string matriculaSolicitante)
            => await _controleAnaliseDesembolso.RemoverComentario(coRegistroValidacao, matriculaSolicitante);
        public async Task ValidarDesembolso(int coDesembolso)
            => await _controleAnaliseDesembolso.ValidarDesembolso(coDesembolso);
        public async Task ValidarTodosPendentes()
            => await _controleAnaliseDesembolso.ValidarTodosPendentes();
        public async Task<List<DesembolsoResponse>> ObterTodosDesembolsos()
            => await _controleAnaliseDesembolso.ObterTodosDesembolsos();
        public async Task VincularResponsavel(int coDesembolso, string? matriculaResponsavel)
            => await _controleAnaliseDesembolso.VincularResponsavel(coDesembolso, matriculaResponsavel);
        public async Task<List<ValidacaoTemplateResponse>> ObterValidacoesTemplate()
            => await _controleAnaliseDesembolso.ObterValidacoesTemplate();
        public async Task<List<ComentarioValidacaoResponse>> ObterComentarios(int coDesembolso)
            => await _controleAnaliseDesembolso.ObterComentarios(coDesembolso);
        public async Task<DesembolsoDetalheResponse> ObterDetalheDesembolso(int coDesembolso)
            => await _controleAnaliseDesembolso.ObterDetalheDesembolso(coDesembolso);
        public async Task AprovarDesembolso(int coDesembolso, AprovarDesembolsoRequest request)
            => await _controleAnaliseDesembolso.AprovarDesembolso(coDesembolso,request);
		public async Task BaixarDRP(int coDesembolso)
			=> await _controleAnaliseDesembolso.BaixarDRP(coDesembolso);

        public async Task RejeitarDesembolso(int coDesembolso, RejeitarDesembolsoRequest request)
            => await _controleAnaliseDesembolso.RejeitarDesembolso(coDesembolso,request);
        public async Task<List<RegistroDrpResponse>> ObterRegistrosDrp()
            => await _controleAnaliseDesembolso.ObterRegistrosDrp();
        public async Task BaixarDrpEmLote(BaixarDrpRequest request)
            => await _controleAnaliseDesembolso.BaixarDrpEmLote(request);


        //public async Task<string?> ObterREsponsavelDesembolso(int coFpd) 
        //	=> await _consultaAnaliseDesembolso.ObterREsponsavelDesembolso(coFpd);

        //public async Task CriarFichaPedidoDesembolso(PedidoDesembolsoRequest request)
        //	=> await _consultaAnaliseDesembolso.CriarFichaPedidoDesembolso(request);

        //public async Task AdicionarComentario(ValidacaoDesembolsoRequest request)
        //	=> await _consultaAnaliseDesembolso.AdicionarComentario(request);
        #endregion
    }
}
