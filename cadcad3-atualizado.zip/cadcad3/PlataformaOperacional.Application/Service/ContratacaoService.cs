﻿using ChecklistContratacao.Application.Interface;
using ChecklistContratacao.Domain.Dto;
using ChecklistContratacao.Domain.Model;
using PlataformaOperacional.Application.Service.Interface;
using RedeCaixaUtilitario.Domain.Model;
using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios.Model;
using Utilitarios.Service;

namespace PlataformaOperacional.Application.Service
{
	public class ContratacaoService : IContratacaoService
	{
		private readonly IPlataformaOperacionalService _plataformaService;
		private UtilitarioMapperService _mapper = new UtilitarioMapperService();

		private readonly IChecklistContratacaoService _checklistService;
		public ContratacaoService(IPlataformaOperacionalService plataformaService, IChecklistContratacaoService checklistService)
		{
			_plataformaService = plataformaService;
			_checklistService = checklistService;
		}

		public async Task<ReadContratosChecklistDto?> ConsultarChecklist(string contrato)
		{
			var podeFinalizar = await _plataformaService.VerificaFuncionalidadeAutorizadaAsync("FinalizarChecklistContrato");
			var podeCancelar =  await _plataformaService.VerificaFuncionalidadeAutorizadaAsync("CancelarFinalizacaoContrato");

			var contratos = await _checklistService.ConsultarChecklist(contrato,podeFinalizar,podeCancelar);
			return contratos;
		}

		public async Task<bool> CarregarChecklistContratosCarregados()
		{
			var usuario = _plataformaService.IdentificarUsuario();
			await _checklistService.CarregarChecklistContratosCarregados(usuario);
			return true;
		}
	
		public async Task<bool> AtualizarChecklist(RespostaChecklist resposta)
		{
			var usuario = _plataformaService.IdentificarUsuario();
			var response = await _checklistService.AtualizarChecklist(resposta, usuario);
			return response;
		}
		public async Task<List<TipoRespostaChecklist>> ConsultarRespostasChecklist()
		{		
			var response = await _checklistService.ConsultarRespostasChecklist();
			return response;
		}
		public async Task<List<ReadContratosChecklistResumoDto>> ConsultaContratosParaConformidadeAsync()
		{
			var response = await _checklistService.ConsultaContratosParaConformidadeAsync();
			return response;
		}
		public async Task<List<Tomador>> ConsultarTomadores()
		{
			var response = await _checklistService.ConsultarTomadores();
			return response;
		}
		public async Task<List<ResumoTomador>> ConsultarResumosTomador()
		{
			var response = await _checklistService.ConsultarResumosTomador();
			return response;
		}
		public async Task<List<ResumoGeralChecklist>> ConsultarResumoGeralChecklist()
		{
			var response = await _checklistService.ConsultarResumoGeralChecklist();
			return response;
		}
		public async Task<ResumoTomador> ConsultarResumoTomadorPorCoTomadorAsync(string CoTomador)
		{
			var response = await _checklistService.ConsultarResumoTomadorPorCoTomadorAsync(CoTomador);
			return response;
		}
		public async Task<bool> CadastrarRessalvaAsync(CreateRessalvaChecklistDto ressalvaDto)
		{
			var usuario = _plataformaService.IdentificarUsuario();
			var response = await _checklistService.CadastrarRessalvaAsync(ressalvaDto, usuario);
			return true;
		}
		public async Task<bool> AtualizarRessalvaAsync(RespostaRessalva ressalva)
		{
			var usuario = _plataformaService.IdentificarUsuario();
			var response = await _checklistService.AtualizarRessalvaAsync(ressalva, usuario);
			return true;
		}
		public async Task<List<ReadRessalvaChecklistDto>> ConsultarRessalvaPorContratoAsync(string contrato)
		{
			var response = await _checklistService.ConsultarRessalvaPorContratoAsync(contrato);
			return response;
		}
		public async Task DesativarRessalvaAsync(int idRessalva)
		{
			var usuario = _plataformaService.IdentificarUsuario();
			await  _checklistService.DesativarRessalvaAsync(idRessalva, usuario);		
		}
		public async Task<bool> FinalizaChecklistContrato(string coContrato)
		{
			var usuario = _plataformaService.IdentificarUsuario();
			var response = await _checklistService.FinalizaChecklistContrato(coContrato, usuario);
			return true;
		}
		public async Task<List<ResumoContratos>?> ConsultarResumoTodosContratos()
		{
			var response = await _checklistService.ConsultarResumoTodosContratos();
			return response;
		}

		public async Task<bool> CancelarFinalizacaoChecklistContrato(string coContrato)
		{
			var usuario = _plataformaService.IdentificarUsuario();
			var response = await _checklistService.CancelarFinalizacaoChecklistContrato(coContrato, usuario);
			return true;
		}
	}
}
