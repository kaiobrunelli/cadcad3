﻿using ConsultaCrf.Application.Interface;
using ConsultaCrf.Domain.Dto;
using ConsultaCrf.Domain.Model;
using EntradaDeDados.Application.Interface;
using EntradaDeDados.Domain.Dto;
using PlataformaOperacional.Application.Service.Interface;
using RedeCaixaUtilitario.Domain.Model;
using SaldoResidual.Application.Interface;
using SaldoResidual.Domain.Dto;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilitarios.Model;
using Utilitarios.Service;

namespace PlataformaOperacional.Application.Service
{
	public class MonitoramentoService : IMonitoramentoService
	{

		private readonly IConsultaCrfService _consultaCrfService;
		private readonly IPlataformaOperacionalService _plataformaService;
        private readonly IEntradaDeDadosService _entradaDeDadosService;
        private UtilitarioMapperService _mapper = new UtilitarioMapperService();
		public MonitoramentoService(IPlataformaOperacionalService plataformaService, IConsultaCrfService consultaCrfService, IEntradaDeDadosService entradaDeDadosService)
		{
			_plataformaService = plataformaService;
			_consultaCrfService = consultaCrfService;
            _entradaDeDadosService = entradaDeDadosService;
        }

		#region Consulta CRF

		public async Task RealizarOperacaoCrf(PedidoDeAutomacao pedido)
		{
			try
			{
				_consultaCrfService.RealizarOperacaoCrf(pedido);
				await _plataformaService.SaveAsync();
			}
			catch (Exception ex)
			{
				pedido.Obs = ex.Message;
				await _plataformaService.SaveAsync();
				throw;
			}
		}

		public ReadConsultadoCrfDto ConsultarCrfAtual()
		{
			var consultas = _consultaCrfService.ConsultarCrfAtual();
			var consultasDto = _mapper.Map<ReadConsultaCrfDto>(consultas);

			var resposta = new ReadConsultadoCrfDto()
			{
				Consultas = consultasDto,
				BotaoExecutar = true
			};

			if (!consultas.Where(c=>c.IcStatus ==0).Any())
			{
				resposta.BotaoExecutar = false;
			}

			return resposta;
		}
		public ReadConsultadoCrfDto ConsultarCrfAnteriores(DateTime data)
		{
			var consultas = _consultaCrfService.ConsultarCrfAnteriores(data);
			var consultasDto = _mapper.Map<ReadConsultaCrfDto>(consultas);

			var resposta = new ReadConsultadoCrfDto()
			{
				Consultas = consultasDto,
				BotaoExecutar = false //São dados de arquivo
			};

			return resposta;

		}

        #endregion

        #region Entrada de Dados
        public Task<ServiceResult> IncluirEntradaDados(List<EntradaDadosDto> entradaDados)
        {
            var usuario = _plataformaService.IdentificarUsuario();
            return _entradaDeDadosService.IncluirDados(entradaDados, usuario);
        }

        public async Task<DateTime?> ConsultarUltimoControle()
        {
            return await _entradaDeDadosService.ConsultarUltimoControle();
        }
        #endregion



    }
}
