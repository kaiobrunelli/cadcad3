﻿using PlataformaNotificacao.Domain;
using PlataformaNotificacao.Domain.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PlataformaNotificacao.Domain
{
    public class NotificacaoEventArgs : EventArgs
    {
        public string ChaveConexao { get; set; } = "ReceberNotificacao";
        public EscopoNotificacao Escopo { get; set; } = EscopoNotificacao.Geral;
        public List<string> Destinatarios { get; set; } = [];   // matrículas
        public MensagemNotificacao Mensagem { get; set; } = new();
    }
}
