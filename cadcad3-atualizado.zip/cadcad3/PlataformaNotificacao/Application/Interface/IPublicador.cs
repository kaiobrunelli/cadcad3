﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PlataformaNotificacao.Application.Interface
{
    public interface IPublicador
    {
        Task PublicarAsync<TEvent>(TEvent evento) where TEvent : class;
    }
}
