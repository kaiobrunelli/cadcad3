﻿using PlataformaNotificacao.Application.Interface;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PlataformaNotificacao.Application
{
    public class Publicador(IServiceProvider provider) : IPublicador
    {
        public async Task PublicarAsync<TEvent>(TEvent evento) where TEvent : class
        {
            var handlers = provider.GetServices<IEventHandler<TEvent>>();
            foreach(var handler in handlers) 
               await handler.Handle(evento);
        }
    }
}
