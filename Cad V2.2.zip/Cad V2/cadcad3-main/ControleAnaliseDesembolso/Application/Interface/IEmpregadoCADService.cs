using ControleAnaliseDesembolso.Domain.Entitys;

namespace ControleAnaliseDesembolso.Application.Interface
{
    public interface IEmpregadoCADService
    {
        Task<List<Empregado>> ObterTodos();
        Task<Empregado?> ObterPorMatricula(string matricula);

        // Atribuir analista é ação exclusiva de CEFGA — a lista do popover deve
        // vir filtrada pela coordenação de quem analisa (ex.: "CEFGA06"), não de
        // todos os empregados ativos.
        Task<List<Empregado>> ObterPorCoordenacao(string codigoCoordenacao);
    }
}
