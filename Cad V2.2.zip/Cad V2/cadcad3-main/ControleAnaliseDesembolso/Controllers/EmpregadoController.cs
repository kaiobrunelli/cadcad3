using ControleAnaliseDesembolso.Application.Interface;
using ControleAnaliseDesembolso.Domain.Entitys;
using Microsoft.AspNetCore.Mvc;

namespace ControleAnaliseDesembolso.Controllers
{
    [ApiController]
    [Route("/api/[action]")]
    public class EmpregadoController : ControllerBase
    {
        private readonly IEmpregadoCADService _empregados;

        public EmpregadoController(IEmpregadoCADService empregados)
        {
            _empregados = empregados;
        }

        // Popover "Atribuir analista" — filtra pela coordenação de quem analisa
        // (ex.: CEFGA06), não lista todo mundo ativo.
        [HttpGet]
        public async Task<ActionResult<List<Empregado>>> ObterEmpregadosPorCoordenacao([FromQuery] string coordenacao)
            => Ok(await _empregados.ObterPorCoordenacao(coordenacao));
    }
}
