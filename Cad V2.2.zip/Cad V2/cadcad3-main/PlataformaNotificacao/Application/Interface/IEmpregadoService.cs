﻿using PlataformaNotificacao.Application.Interface;
using PlataformaNotificacao.Domain.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PlataformaNotificacao.Application.Interface
{
    public interface IEmpregadoService
    {
        List<string> ObterMatriculasTodos();
        Task<List<string>> ObterTodasMatriculas();
        Task<List<string>> ObterMatriculasPorCoordenacao(string codigoCoordenacao);
        List<string> ObterMatriculasPorModulo(string modulo);
        List<string> FiltrarMatriculasValidas(IEnumerable<string> matriculas);

        // Matrículas GIGOV ativas — vêm de PLA_NOT_TB003_EMPREGADOS_GIGOV, não da
        // RH_TB003 (não existe fonte de RH pra GIGOV, ver EmpregadoGigov).
        Task<List<string>> ObterMatriculasGigov();

        // Só os empregados cadastrados NAQUELE número de GIGOV (ex.: "7171") —
        // é o que deve ser usado pra notificar quem abriu uma FPD específica,
        // nunca ObterMatriculasGigov() (que traria gente de outras GIGOVs).
        Task<List<string>> ObterMatriculasGigovPorNumero(string codigoGigov);

        // Coordenador (gestor) ativo da coordenação; se estiver de férias, devolve
        // o eventual dele no lugar. Null se não houver ninguém pra notificar.
        Task<string?> ObterGestorAtivoOuEventualAsync(string codigoCoordenacao);
    }
}



