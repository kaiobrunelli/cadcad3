namespace PlataformaNotificacao.Domain
{
    // Controle próprio (não vem do RH) de quem é GIGOV cadastrado pra
    // notificações — não existe fonte externa equivalente à RH_TB003 pra GIGOV,
    // então essa tabela é a fonte da verdade aqui mesmo.
    public class EmpregadoGigov
    {
        public int CodigoEmpregado { get; set; }

        public string Matricula { get; set; } = "";

        public string Nome { get; set; } = "";

        // Número da GIGOV que esse empregado atende (ex.: "7000", "7171") — o
        // MESMO número que vem em FichaPedidoDesembolso.CoGigov. Uma notificação
        // pra "a GIGOV" tem que ir só pra quem está cadastrado nesse número
        // específico, não pra todo mundo da tabela.
        public string CodigoGigov { get; set; } = "";

        public bool Ativo { get; set; } = true;
    }
}
